// SC NYA JANGAN DI JUAL NGENTOD
//MAKASIH DAH PAKE 
const
	{
		WAConnection,
		MessageType,
		Presence,
		MessageOptions,
		Mimetype,
		WALocationMessage,
		WA_MESSAGE_STUB_TYPES,
		WA_DEFAULT_EPHEMERAL,
		ReconnectMode,
		ProxyAgent,
		GroupSettingChange,
		waChatKey,
		mentionedJid,
		processTime,
	} = require("@adiwajshing/baileys")
const hx = require('hxz-api')
const qrcode = require("qrcode-terminal")
const moment = require("moment-timezone")
const speed = require('performance-now')
const request = require('request');
const { spawn, exec, execSync } = require("child_process")
const fs = require("fs")
const axios = require("axios")
const ffmpeg = require('fluent-ffmpeg')
const { EmojiAPI } = require("emoji-api");
const ig = require('insta-fetcher')
const emoji = new EmojiAPI()
const fetch = require('node-fetch');
const phoneNum = require('awesome-phonenumber')
const gis = require('g-i-s');
const got = require("got");
const imageToBase64 = require('image-to-base64');
const ID3Writer = require('browser-id3-writer');		
const brainly = require('brainly-scraper')
const yts = require( 'yt-search')
const ms = require('parse-ms')
const toMs = require('ms')
const Exif = require('./lib/exifi')
const exif = require('./lib/exifi')
const { error } = require("qrcode-terminal")
const { getBuffer, h2k, generateMessageID, getGroupAdmins, getRandom, banner, start, info, success, close } = require('./lib/functions')
const { color, bgcolor } = require('./lib/color')
const { fetchJson, getBase64, kyun, createExif } = require('./lib/fetcher')
const { yta, ytv, igdl, upload, formatDate } = require('./lib/ytdl')
const { webp2mp4File} = require('./lib/webp2mp4')
const time = moment().tz('Asia/Kolkata').format("HH:mm:ss")
const afk = JSON.parse(fs.readFileSync('./lib/off.json'))
const { sleep, isAfk, cekafk, addafk } = require('./lib/offline')
const voting = JSON.parse(fs.readFileSync('./lib/voting.json'))
const { addVote, delVote } = require('./lib/vote')
const { jadibot, stopjadibot, listjadibot } = require('./lib/jadibot')
const jm = moment.tz('Asia/Kolkata').format('HH:mm:ss')

fEVA = true
banChats = true
offline = false
targetpc = '919446088620'
owner = '919446088620'
fake = 'White Walker'
numbernye = '0'
waktu = '-'
alasan = '-'
//=================================================//
module.exports = hexa = async (hexa, mek) => {
	try {
        if (!mek.hasNewMessage) return
        mek = mek.messages.all()[0]
		if (!mek.message) return
		if (mek.key && mek.key.remoteJid == 'status@broadcast') return
		global.blocked
        	mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message
        	const content = JSON.stringify(mek.message)
		const from = mek.key.remoteJid
		const { text, extendedText, contact, location, liveLocation, image, video, sticker, document, audio, product } = MessageType
		const time = moment.tz('Asia/Kolkata').format('DD/MM HH:mm:ss')
                const type = Object.keys(mek.message)[0]        
                const cmd = (type === 'conversation' && mek.message.conversation) ? mek.message.conversation : (type == 'imageMessage') && mek.message.imageMessage.caption ? mek.message.imageMessage.caption : (type == 'videoMessage') && mek.message.videoMessage.caption ? mek.message.videoMessage.caption : (type == 'extendedTextMessage') && mek.message.extendedTextMessage.text ? mek.message.extendedTextMessage.text : ''.slice(1).trim().split(/ +/).shift().toLowerCase()
                const prefix = /^[!.]/.test(cmd) ? cmd.match(/^[!.]/gi) : '-'          	
        body = (type === 'listResponseMessage' && mek.message.listResponseMessage.selectedDisplayText) ? mek.message.listResponseMessage.selectedDisplayText : (type === 'conversation' && mek.message.conversation.startsWith(prefix)) ? mek.message.conversation : (type == 'imageMessage') && mek.message.imageMessage.caption.startsWith(prefix) ? mek.message.imageMessage.caption : (type == 'videoMessage') && mek.message.videoMessage.caption.startsWith(prefix) ? mek.message.videoMessage.caption : (type == 'extendedTextMessage') && mek.message.extendedTextMessage.text.startsWith(prefix) ? mek.message.extendedTextMessage.text : ''
		budy = (type === 'conversation') ? mek.message.conversation : (type === 'extendedTextMessage') ? mek.message.extendedTextMessage.text : ''
		const command = body.slice(1).trim().split(/ +/).shift().toLowerCase()		
		const args = body.trim().split(/ +/).slice(1)
		const isCmd = body.startsWith(prefix)
		const q = args.join(' ')
		const botNumber = hexa.user.jid
		const botNumberss = hexa.user.jid + '@c.us'
		const isGroup = from.endsWith('@g.us')
		let sender = isGroup ? mek.participant : mek.key.remoteJid
		// const isSelfNumber = config.NomorSELF
		// const isOwner = sender.id === isSelfNumber
		const totalchat = await hexa.chats.all()
		const groupMetadata = isGroup ? await hexa.groupMetadata(from) : ''
		const groupName = isGroup ? groupMetadata.subject : ''
		const groupId = isGroup ? groupMetadata.jid : ''
		const groupMembers = isGroup ? groupMetadata.participants : ''
		const groupDesc = isGroup ? groupMetadata.desc : ''
		const groupOwner = isGroup ? groupMetadata.owner : ''
		const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ''
		const isBotGroupAdmins = groupAdmins.includes(botNumber) || false
		const isGroupAdmins = groupAdmins.includes(sender) || false
        const isVote = isGroup ? voting.includes(from) : false
        const conts = mek.key.fromMe ? hexa.user.jid : hexa.contacts[sender] || { notify: jid.replace(/@.+/, '') }
        const pushname = mek.key.fromMe ? hexa.user.name : conts.notify || conts.vname || conts.name || '-'
            const date = moment.tz('Asia/Kolkata').format('DD/MM/YY')
            const hr = moment.tz('Asia/Kolkata').format('HH:mm:ss')
            const timi = moment.tz('Asia/Kolkata').add(30, 'days').calendar();
            const timu = moment.tz('Asia/Kolkata').add(20, 'days').calendar();
             let d = new Date
    let locale = 'en'
				    let times = d.toLocaleTimeString(locale, {
      hour: 'numeric',
      minute: 'numeric'
    })
        let dates = d.toLocaleDateString(locale, {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })
   let timer = moment.tz('Asia/Kolkata').format('HH')
    var autoTimeZone = 'Good Morning 🌄'
				if (timer >= '03' && timer <= '10') {
				autoTimeZone = 'Good Morning 🌄'
				} else if (timer >= '10' && timer <= '13') {
				autoTimeZone = 'Good Afternoon ☀️'
				} else if (timer >= '13' && timer <= '18') {
				autoTimeZone = 'good evening 🌆'
				} else if (timer >= '18' && timer <= '23') {
				autoTimeZone = 'Good Night 🌃'
				} else {
				autoTimeZone = 'Good Night 🌌'
				}
const emo = ["➬","➫","➪","➩","➭"]
emojix = emo[Math.floor(Math.random() * emo.length)]
const emo1 = ["➳","➵","➺","➸","➻"]
emoji1 = emo1[Math.floor(Math.random() * emo1.length)]
const emo2 = ["✢","✣","✤","✥","✦"]
emoji2 = emo2[Math.floor(Math.random() * emo2.length)]
const emo3 = ["✧","✩","✪","✫","✬"]
emoji3 = emo3[Math.floor(Math.random() * emo3.length)]
const emo4 = ["✭","✮","✯","✰","✲"]
emoji4 = emo4[Math.floor(Math.random() * emo4.length)]
const emo5 = ["✲","⧐","⧴","✵","✶"]
emoji5 = emo5[Math.floor(Math.random() * emo5.length)]
const emo6 = ["❃","❆","❅","❈","⩥"]
emoji6 = emo6[Math.floor(Math.random() * emo6.length)]
const exifi = new Exif()
const unicodea = "ᷧ"
const unicodeb = "ᷨ"
const unicodec = "ͨ"
const unicoded = "ͩ"
const unicodef = "ᷫ"
const unicodeg = "ᷚ"
const unicodeh = "ͪ"
const unicodei = "ͥ"
const unicodej = "ᷯ"
const unicodek = "ᷜ"
const unicodel = "ᷞ"
const unicodem = "ͫ"
const unicoden = "ᷠ"
const unicodeo = "ͦ"
const unicodep = "ᷮ"
const unicodeq = "ᷭ"
const unicoder = "ͬ"
const unicodes = "ᷤ"
const unicodet = "ͭ"
const unicodeu = "ͧ"
const unicodev = "ͮ"
const unicodew = "ᷱ"
const unicodex = "ͯ"
const unicodey = "ꙷ"
const unicodez = "ᷦ"
const unicodee = "ͤ"
const muaud = ["0","1","2","3","4","5"]
muxo = muaud[Math.floor(Math.random() * muaud.length)]
const dnsnewx = fs.readFileSync('./xmenu.jpeg')
const dnsnew = fs.readFileSync('./src/dragonser.jpg')
const sotoy = JSON.parse(fs.readFileSync('./data/sotoy.json'))
        //MESS
		mess = {
			wait: '\`\`\`⊷️「 Wait a minute 」\`\`\`',
			success: '\`\`\`⊷️「 Success 」\`\`\`',
			error: {
				stick: '\`\`\`⊷️「 Cannot access videos! 」\`\`\`',
				Iv: '\`\`\`⊷️「 Invalid link! 」\`\`\`',
                api: '\`\`\`⊷️「 Error 」\`\`\`'
			},
			only: {
				group: '\`\`\`⊷️「 Only for within the group! 」\`\`\`',
				ownerG: '\`\`\`⊷️「 Only for group owners! 」\`\`\`',
				ownerB: '\`\`\`⊷️「 Only for bot owners! 」\`\`\`',
				admin: '\`\`\`⊷️「 Only for group admins! 」\`\`\`',
				Badmin: '\`\`\`⊷️「 Make the bot a group admin! 」\`\`\`'
			}
		}
		const isUrl = (url) => {
        return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%.+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%+.~#?&/=]*)/, 'gi'))
        }

        const reply = (tej) => {
				hexa.sendMessage(from, tej, text, {thumbnail: dnsnew, sendEphemeral: true,quoted:mek})
			}
			const sendMess = (teks) => {
				hexa.sendMessage(from, teks, text)
			}
            const sendImage = (tis) => {
		        hexa.sendMessage(from, tis, image, {thumbnail: dnsnew, sendEphemeral: true,quoted:mek})
		   }              
			const mentions = (ops, memberr, sender, id) => {
				(id == null || id == undefined || id == false) ? hexa.sendMessage(from, ops.trim(), extendedText, {contextInfo: {"mentionedJid": memberr}}) : hexa.sendMessage(from, ops.trim(), extendedText, {thumbnail: dnsnew, sendEphemeral: true,quoted: mek, contextInfo: {"mentionedJid": memberr}})
			}
			const costum = (pesan, tipe, target, target2) => {
                 hexa.sendMessage(from, pesan, tipe, {quoted: {key: {fromMe: false, participant: `${target}`, ...(from ? {remoteJid: from}: {})}, message: {conversation: `${target2}` }}})
            }
             const sendPtt = (teks) => {
                 hexa.sendMessage(from, audio, mp3, {thumbnail: dnsnew, sendEphemeral: true,quoted: mek })
            }
        const fakestatus = (teks) => {
            hexa.sendMessage(from, teks, text, {
                quoted: {
                    key: {
                        fromMe: false,
                        participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {})
                    },
                    message: {
                        "imageMessage": {
                            "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc",
                            "mimetype": "image/jpeg",
                            "caption": fake,
                            "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=",
                            "fileLength": "28777",
                            "height": 1080,
                            "width": 1079,
                            "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=",
                            "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=",
                            "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69",
                            "mediaKeyTimestamp": "1610993486",
                            "jpegThumbnail": fs.readFileSync('./stik/thumb.jpeg'),
                            "scansSidecar": "1W0XhfaAcDwc7xh1R8lca6Qg/1bB4naFCSngM2LKO2NoP5RI7K+zLw=="
                        }
                    }
                }
            })
        }
        const fakethumb = (teks, yes) => {
            hexa.sendMessage(from, teks, image, {thumbnail:fs.readFileSync('./stik/fake.jpeg'),quoted:mek,caption:yes})
        }
        const fakegroup = (teks) => {
            hexa.sendMessage(from, teks, text, {
                quoted: {
                    key: {
                        fromMe: false,
                        participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "6289523258649-1604595598@g.us" } : {})
                    },
                    message: {
                        "imageMessage": {
                            "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc",
                            "mimetype": "image/jpeg",
                            "caption": fake,
                            "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=",
                            "fileLength": "28777",
                            "height": 1080,
                            "width": 1079,
                            "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=",
                            "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=",
                            "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69",
                            "mediaKeyTimestamp": "1610993486",
                            "jpegThumbnail": fs.readFileSync('./stik/thumb.jpeg'),
                            "scansSidecar": "1W0XhfaAcDwc7xh1R8lca6Qg/1bB4naFCSngM2LKO2NoP5RI7K+zLw=="
                        }
                    }
                }
            })
        }
        const sendStickerFromUrl = async(to, url) => {
                var names = Date.now() / 10000;
                var download = function (uri, filename, callback) {
                    request.head(uri, function (err, res, body) {
                        request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                    });
                };
                download(url, './stik' + names + '.png', async function () {
                    console.log('selesai');
                    let filess = './stik' + names + '.png'
                    let asw = './stik' + names + '.webp'
                    exec(`ffmpeg -i ${filess} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${asw}`, (err) => {
                        let media = fs.readFileSync(asw)
                        hexa.sendMessage(to, media, MessageType.sticker,{quoted:mek})
                        fs.unlinkSync(filess)
                        fs.unlinkSync(asw)
                    });
                });
            }
        const sendMediaURL = async(to, url, text="", mids=[]) =>{
                if(mids.length > 0){
                    text = normalizeMention(to, text, mids)
                }
                const fn = Date.now() / 10000;
                const filename = fn.toString()
                let mime = ""
                var download = function (uri, filename, callback) {
                    request.head(uri, function (err, res, body) {
                        mime = res.headers['content-type']
                        request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                    });
                };
                download(url, filename, async function () {
                    console.log('done');
                    let media = fs.readFileSync(filename)
                    let type = mime.split("/")[0]+"Message"
                    if(mime === "image/gif"){
                        type = MessageType.video
                        mime = Mimetype.gif
                    }
                    if(mime.split("/")[0] === "audio"){
                        mime = Mimetype.mp4Audio
                    }
                    hexa.sendMessage(to, media, type, { quoted: mek, mimetype: mime, caption: text,contextInfo: {"mentionedJid": mids}})
                    
                    fs.unlinkSync(filename)
                });
            }   
//FUNCTION
            cekafk(afk)
            if (!mek.key.remoteJid.endsWith('@g.us') && offline){
            if (!mek.key.fromMe){
            if (isAfk(mek.key.remoteJid)) return
            addafk(mek.key.remoteJid)
            heheh = ms(Date.now() - waktu) 
            hexa.sendMessage(mek.key.remoteJid,`@${owner} Sedang Offline!\n\n*Alasan :* ${alasan}\n*Sejak :* ${heheh.hours} Jam, ${heheh.minutes} Menit, ${heheh.seconds} Detik lalu\n\nSilahkan Hubungi Lagi Nanti`, MessageType.text,{contextInfo:{ mentionedJid: [`${owner}@s.whatsapp.net`],'stanzaId': "B826873620DD5947E683E3ABE663F263", 'participant': "0@s.whatsapp.net", 'remoteJid': 'status@broadcast', 'quotedMessage': {"imageMessage": {"caption": "*OFFLINE*", 'jpegThumbnail': fs.readFileSync('./stik/thumb.jpeg')}}}})
            }
            }   
        if (mek.key.remoteJid.endsWith('@g.us') && offline) {
        if (!mek.key.fromMe){
        if (mek.message.extendedTextMessage != undefined){
        if (mek.message.extendedTextMessage.contextInfo != undefined){
        if (mek.message.extendedTextMessage.contextInfo.mentionedJid != undefined){
        for (let ment of mek.message.extendedTextMessage.contextInfo.mentionedJid) {
        if (ment === `${owner}@s.whatsapp.net`){
        if (isAfk(mek.key.remoteJid)) return
        addafk(mek.key.remoteJid)
        heheh = ms(Date.now() - waktu)
        hexa.sendMessage(mek.key.remoteJid,`@${owner} Sedang Offline!\n\n *Alasan :* ${alasan}\n *Sejak :* ${heheh.hours} Jam, ${heheh.minutes} Menit, ${heheh.seconds} Detik lalu\n\nSilahkan Hubungi Lagi Nanti`, MessageType.text,{contextInfo:{ mentionedJid: [`${owner}@s.whatsapp.net`],'stanzaId': "B826873620DD5947E683E3ABE663F263", 'participant': "0@s.whatsapp.net", 'remoteJid': 'status@broadcast', 'quotedMessage': {"imageMessage": {"caption": "*OFFLINE*", 'jpegThumbnail': fs.readFileSync('./stik/thumb.jpeg')}}}})
          }
        }
            }
          }
        }
      }
    }
//========================================================================================================================//
		colors = ['red', 'white', 'black', 'blue', 'yellow', 'green']
		const isMedia = (type === 'imageMessage' || type === 'videoMessage')
		const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
		const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
		const isQuotedAudio = type === 'extendedTextMessage' && content.includes('audioMessage')
		const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')
      	if (!isGroup && isCmd) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32mEXEC\x1b[1;37m]', time, color(command), 'from', color(sender.split('@')[0]), 'args :', color(args.length))
      	//if (!isGroup && !isCmd) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;31mTEXT\x1b[1;37m]', time, color('Message'), 'from', color(sender.split('@')[0]), 'args :', color(args.length))
     	if (isCmd && isGroup) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32mEXEC\x1b[1;37m]', time, color(command), 'from', color(sender.split('@')[0]), 'in', color(groupName), 'args :', color(args.length))
      	//if (!isCmd && isGroup) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;31mTEXT\x1b[1;37m]', time, color('Message'), 'from', color(sender.split('@')[0]), 'in', color(groupName), 'args :', color(args.length))
	    if(isGroup && !isVote) {
        if (budy.toLowerCase() === 'vote'){
        let vote = JSON.parse(fs.readFileSync(`./lib/${from}.json`))
        let _votes = JSON.parse(fs.readFileSync(`./lib/vote/${from}.json`))  
        let fil = vote.map(v => v.participant)
        let id_vote = sender ? sender : '919446088620@s.whatsapp.net'
        if(fil.includes(id_vote)) {
        return mentions('@'+sender.split('@')[0]+' Anda sudah vote', fil, true)
        } else {
        vote.push({
            participant: id_vote,
            voting: '✅'
        })
        fs.writeFileSync(`./lib/${from}.json`,JSON.stringify(vote))
        let _p = []
        let _vote = '*Vote* '+ '@'+ _votes[0].votes.split('@')[0] + `\n\n*Reason*: ${_votes[0].reason}\n*Number of Votes* : ${vote.length} Vote\n*Duration* : ${_votes[0].durasi} Minute\n\n` 
        for(let i = 0; i < vote.length; i++) {
        _vote +=  `@${vote[i].participant.split('@')[0]}\n*Vote* : ${vote[i].voting}\n\n`
        _p.push(vote[i].participant)
        }  
        _p.push(_votes[0].votes)
        mentions(_vote,_p,true)   
        }
        } else if (budy.toLowerCase() === 'devote'){
        const vote = JSON.parse(fs.readFileSync(`./lib/${from}.json`))
        let _votes = JSON.parse(fs.readFileSync(`./lib/vote/${from}.json`))  
        let fil = vote.map(v => v.participant)
        let id_vote = sender ? sender : '919446088620@s.whatsapp.net'
        if(fil.includes(id_vote)) {
        return mentions('@'+sender.split('@')[0]+' You have already voted', fil, true)
        } else {
        vote.push({
            participant: id_vote,
            voting: '❌'
        })
        fs.writeFileSync(`./lib/${from}.json`,JSON.stringify(vote))
        let _p = []
        let _vote = '*Vote* '+ '@'+ _votes[0].votes.split('@')[0] + `\n\n*Reason*: ${_votes[0].reason}\n*Number of Votes* : ${vote.length} Vote\n*Duration* : ${_votes[0].durasi} Minute\n\n` 
        for(let i = 0; i < vote.length; i++) {
        _vote +=  `@${vote[i].participant.split('@')[0]}\n*Vote* : ${vote[i].voting}\n\n`
        _p.push(vote[i].participant)
        }  
        _p.push(_votes[0].votes)
        mentions(_vote,_p,true)   
        }
    }
}	
if (fEVA === false) return
switch (command) 
{
case 'dance':
case 'spider':
case 'blackbird':
case 'text3d':
case 'wroom':
case 'surfboard':
case 'orlando':
case 'matrix':
case 'trance':         
				reply(mess.wait)
                    if (args.length == 0) return reply(`Example: ${prefix + command} loop`)
                    ini_txt = args.join(" ")
                    ini_buffer = await getBuffer(`https://bx-hunter.herokuapp.com/api/flamingtext/${command}?text=${ini_txt}&apikey=Ikyy69`)
                    hexa.sendMessage(from, ini_buffer, image, { quoted: mek })               
                    break

case 'play':
			if (args.length === 0) return reply(`Kirim perintah *${prefix}play* _Judul lagu yang akan dicari_`)
			if (!mek.key.fromMe && !isGroupAdmins) return reply(mess.only.admin)
            var srch = args.join('')
    		aramas = await yts(srch);
    		aramat = aramas.all 
   			var mulaikah = aramat[0].url							
                  try {
                    yta(mulaikah)
                    .then((res) => {
                        const { dl_link, thumb, title, filesizeF, filesize } = res
                        axios.get(`https://tinyurl.com/api-create.php?url=${dl_link}`)
                        .then(async (a) => {
                        if (Number(filesize) >= 100000) return sendMediaURL(from, thumb, `*PLAY MUSIC*\n\n*Title* : ${title}\n*Ext* : MP3\n*Filesize* : ${filesizeF}\n*Link* : ${a.data}\n\n_For durations more than the limit are presented in the link ok :v_`)
                        const captions = `*PLAY MUSIC*\n\n*Title* : ${title}\n*Ext* : MP3\n*Size* : ${filesizeF}\n*Link* : ${a.data}\n\n_Please wait for the media file to be sent it may take a few minutes_`
                        sendMediaURL(from, thumb, captions)
                        await sendMediaURL(from, dl_link).catch(() => reply('error'))
                        })                
                        })
                        } catch (err) {
                        reply(mess.error.api)
                        }
                   break
case 'tomp3':
            if (!isQuotedVideo) return fakegroup('Reply the video!')
            if (!mek.key.fromMe && !isGroupAdmins) return reply(mess.only.admin)
            fakegroup(mess.wait)
            encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
            media = await hexa.downloadAndSaveMediaMessage(encmedia)
            ran = getRandom('.mp4')
            exec(`ffmpeg -i ${media} ${ran}`, (err) => {
            fs.unlinkSync(media)
            if (err) return fakegroup(`Err: ${err}`)
            buffer453 = fs.readFileSync(ran)
            hexa.sendMessage(from, buffer453, audio, { mimetype: 'audio/mp4', quoted: mek })
            fs.unlinkSync(ran)
            })
            break
case 'ua':
case 'unicodea':
if (args.length == 0) return reply(`Example: !unicodea ▷`)
ini_txttr = args.join(" ")
reply(`${ini_txttr}${unicodea}`)
break
case 'ub':
case 'unicodeb':
if (args.length == 0) return reply(`Example: !unicodea ▷`)
ini_txttr = args.join(" ")
reply(`${ini_txttr}${unicodeb}`)
break
case 'uc':
case 'unicodec':
if (args.length == 0) return reply(`Example: !unicodea ▷`)
ini_txttr = args.join(" ")
reply(`${ini_txttr}${unicodec}`)
break
case 'ue':
case 'unicodee':
if (args.length == 0) return reply(`Example: !unicodea ▷`)
ini_txttr = args.join(" ")
reply(`${ini_txttr}${unicodee}`)
break
case 'uf':
case 'unicodef':
if (args.length == 0) return reply(`Example: !unicodea ▷`)
ini_txttr = args.join(" ")
reply(`${ini_txttr}${unicodef}`)
break
case 'ug':
case 'unicodeg':
if (args.length == 0) return reply(`Example: !unicodea ▷`)
ini_txttr = args.join(" ")
reply(`${ini_txttr}${unicodeg}`)
break
case 'uh':
case 'unicodeh':
if (args.length == 0) return reply(`Example: !unicodea ▷`)
ini_txttr = args.join(" ")
reply(`${ini_txttr}${unicodeh}`)
break
case 'ui':
case 'unicodei':
if (args.length == 0) return reply(`Example: !unicodea ▷`)
ini_txttr = args.join(" ")
reply(`${ini_txttr}${unicodei}`)
break
case 'uj':
case 'unicodej':
if (args.length == 0) return reply(`Example: !unicodea ▷`)
ini_txttr = args.join(" ")
reply(`${ini_txttr}${unicodej}`)
break
case 'uk':
case 'unicodek':
if (args.length == 0) return reply(`Example: !unicodea ▷`)
ini_txttr = args.join(" ")
reply(`${ini_txttr}${unicodek}`)
break
case 'ul':
case 'unicodel':
if (args.length == 0) return reply(`Example: !unicodea ▷`)
ini_txttr = args.join(" ")
reply(`${ini_txttr}${unicodel}`)
break
case 'um':
case 'unicodem':
if (args.length == 0) return reply(`Example: !unicodea ▷`)
ini_txttr = args.join(" ")
reply(`${ini_txttr}${unicodem}`)
break
case 'un':
case 'unicoden':
if (args.length == 0) return reply(`Example: !unicodea ▷`)
ini_txttr = args.join(" ")
reply(`${ini_txttr}${unicoden}`)
break
case 'uo':
case 'unicodeo':
if (args.length == 0) return reply(`Example: !unicodea ▷`)
ini_txttr = args.join(" ")
reply(`${ini_txttr}${unicodeo}`)
break
case 'up':
case 'unicodep':
if (args.length == 0) return reply(`Example: !unicodea ▷`)
ini_txttr = args.join(" ")
reply(`${ini_txttr}${unicodep}`)
break
case 'uq':
case 'unicodeq':
if (args.length == 0) return reply(`Example: !unicodea ▷`)
ini_txttr = args.join(" ")
reply(`${ini_txttr}${unicodeq}`)
break
case 'ur':
case 'unicoder':
if (args.length == 0) return reply(`Example: !unicodea ▷`)
ini_txttr = args.join(" ")
reply(`${ini_txttr}${unicoder}`)
break
case 'us':
case 'unicodes':
if (args.length == 0) return reply(`Example: !unicodea ▷`)
ini_txttr = args.join(" ")
reply(`${ini_txttr}${unicodes}`)
break
case 'ut':
case 'unicodet':
if (args.length == 0) return reply(`Example: !unicodea ▷`)
ini_txttr = args.join(" ")
reply(`${ini_txttr}${unicodet}`)
break
case 'uu':
case 'unicodeu':
if (args.length == 0) return reply(`Example: !unicodea ▷`)
ini_txttr = args.join(" ")
reply(`${ini_txttr}${unicodeu}`)
break
case 'uv':
case 'unicodev':
if (args.length == 0) return reply(`Example: !unicodea ▷`)
ini_txttr = args.join(" ")
reply(`${ini_txttr}${unicodev}`)
break
case 'uw':
case 'unicodew':
if (args.length == 0) return reply(`Example: !unicodea ▷`)
ini_txttr = args.join(" ")
reply(`${ini_txttr}${unicodew}`)
break
case 'ux':
case 'unicodex':
if (args.length == 0) return reply(`Example: !unicodea ▷`)
ini_txttr = args.join(" ")
reply(`${ini_txttr}${unicodex}`)
break
case 'uy':
case 'unicodey':
if (args.length == 0) return reply(`Example: !unicodea ▷`)
ini_txttr = args.join(" ")
reply(`${ini_txttr}${unicodey}`)
break
case 'uz':
case 'unicodez':
if (args.length == 0) return reply(`Example: !unicodea ▷`)
ini_txttr = args.join(" ")
reply(`${ini_txttr}${unicodez}`)
break
case 'ud':
case 'unicoded':
if (args.length == 0) return reply(`Example: !unicodea ▷`)
ini_txttr = args.join(" ")
reply(`${ini_txttr}${unicoded}`)
break
case 'attp':
if (args.length < 1) return reply(`Use this way:\nCommand: ${prefix}attp Toin cattle`)
attp2 = await getBuffer(`https://api.xteam.xyz/attp?file&text=${encodeURIComponent(body.slice(5))}`)
hexa.sendMessage(from, attp2, sticker, {sendEphemeral: true,quoted: mek})
break
case 'countrycode':
case 'countrycodes':
				
				{
				let poio = hexa.prepareMessageFromContent(from, {
					"listMessage":{
                  "title": "*COUNTRYCODES*",
                  "description": "type !+ (country code)\nExample:\n!+ 7",
                  "buttonText": "OTHERS",
                  "listType": "SINGLE_SELECT",
                  "sections": [
                     {
                        "rows": [
                           {
                              "title": "!countrycodelist",
                              "rowId": `.countrycodelist`
                           }
                        ]
                     }]}}, {}) 
            hexa.relayWAMessage(poio, {waitForAck: true})
			}
break
case 'countrycodelist':
reply("Afganistan 93\nAfrika Selatan 27\nAfrika Tengah 236\nAlbania 355\nAlgeria (Aljazair) 213\nAmerika Serikat 1\nAndorra 376\nAngola 244\nAnguila 1-264\nAntigua 1-268\nAntillen Belanda 599\nArab Saudi 966\nArgentina 54\nArmenia 374\nAruba 297\nAustralia 61\nAustria 43\nAzerbaijan 994\nBahama 1-242\nBahrain 973\nBangladesh 880\nBarbados 1-246\nBarbuda 1-268\nBelanda 31\nBelarus 375\nBelgia 32\nBelize 501\nBenin 229\nBermuda 1-441\nBhutan 975\nBolivia 591\nBosnia dan Herzegovina 387\nBotswana 267\nBrasil 55\nBrunei Darussalam 673\nBulgaria 359\nBurkina Faso 226\nBurundi 257\nCape Verde 238\nCeko 420\nChad 235\nChili 56\nCina 86\nCina Makau 853\nDenmark 45\nDjibouti 253\nDomikia 1-767\nEkuador 593\nEl Salvador 503\nEritrea 291\nEstonia 372\nEthiopia 251\nFiji 679\nFilipina 63\nFinlandia 358\nGabon 241\nGambia 220\nGeorgia 995\nGhana 233\nGibraltar 350\nGreenland 299\nGrenada 1-473\nGuam 1-671\nGuatemala 502\nGuinea 224\nGuinea Bissau 245\nGuinea Ekuator 240\nGuyana 592\nHaiti 509\nHonduras 504\nHongaria 36\nHongkong 852\nIndonesia 62\nIndia 91\nInggris (Britania Raya) 44\nIrak 964\nIran 98\nIrlandia 353\nIslandia 354\nIsrael 972\nItalia 39\nJamaika 1-876\nJepang 81\nJerman 49\nJersey 44-1534\nKamboja 855\nKamerun 237\nKanada 1\nKazakhstan 7\nKenya 254\nKepulauan Marshall 692\nKepulauan Turks dan Caicos 1-649\nKirgizstan 996\nKiribati 686\nKolombia 57\nKomoros 682\nKorea Selatan 82\nKorea Utara 850\nKosta Rika 506\nKroasia 385\nKuba 53\nKuwait 965\nKurakao 599\nLaos 856\nLatvia 371\nLebanon 961\nLesotho 266\nLiberia 231\nLibya 218\nLiechtenstein 423\nLituania 370\nLuksemburg 352\nMadagaskar 261\nMakedonia 389\nMaladewa 960\nMalawi 265\nMalaysia 60\nMali 223\nMalta 356\nMaroko 212\nMauritania 222\nMauritius 230\nMayotte 262\nMeksiko 52\nMesir 20\nMikronesia 691\nMoldova 373\nMonako 377\nMongolia 976\nMontenegro 382\nMozambik 258\nMyanmar 95\nNamibia 264\nNauru 674\nNepal 977\nNiger 227\nNigeria 234\nNikaragua 505\nNiue 683\nNorwegia 47\nOman 968\nPakistan 92\nPalau 680\nPalestina 970\nPanama 507\nPantai Gading 225\nPapua Nugini 675\nParaguay 595\nPerancis 33\nPerancis Polinesia 689\nPeru 51\nPitcairn 64\nPolandia 48\nPortugal 351\nPuerto Riko 1-787, 1-939\nPulau Cocos 61\nPulau Cook 682\nPulau Falkland 500\nPulau Faroe 298\nPulau Man 44-1624\nPulau Mariana Utara 1-670\nPulau Reuni 262\nPulau Solomon 677\nPulau Virgin 1-340\nQatar 974\nRepublik Ceko 420\nRepublik Demokrasi Kongo 243\nRepublik Dominika 1-809, 1-829, 1-849\nRumania 40\nRusia 7\nRwanda 250\nSahara Barat 212\nSanto Barthelemy 590\nSanto Helena 290\nSanto Kitts dan Nevis 1-869\nSanto Lucia 1-758\nSanto Vincent dan Grenadines 1-784\nSamoa 685\nSan Marino 378\nSao Tome dan Principe 239\nSelandia Baru 64\nSenegal 221\nSerbia 381\nSeychelles 248\nSierra Leone 232\nSingapura 65\nSiprus 357\nSlovenia 386\nSlowakia 421\nSomalia 252\nSpanyol 34\nSri Lanka 94\nSudan 249\nSudan 211\nSuriah 963\nSuriname 597\nSvalbard dan Jan Mayen 47\nSwaziland 268\nSwedia 46\nSwiss 41\nTajikistan 992\nTanjung Verde 238\nTanzania 255\nTaiwan 886\nThailand 66\nTimor Leste 670\nTogo 228\nTokelau 690\nTonga 676\nTrinidad dan Tobago 1-868\nTunisia 216\nTurki 90\nTurkmenistan 993\nTuvalu 688\nUganda 256\nUkraina 380\nUni Emirat Arab 971\nUruguay 598\nUzbekistan 998\nVanuatu 678\nVatican 379\nVenezuela 58\nVietnam 84\nWalls dan Futuna 681\nYaman 967\nYunani 30\nYordania 962\nZambia 260\nZimbabwe 263")
break
case 'kl':
if (args.length < 1) return reply('KL Kerala')
if (Number(args[0]) === 01) {
reply('KL-01= Thiruvananthapuram 1989 Thiruvananthapuram CR')
} else if (Number(args[0]) === 02) {
reply('KL-02= Kollam 1989 Kollam BP')
} else if (Number(args[0]) === 03) {
reply('KL-03= Pathanamthitta 1989 Kozhencherry AF')
} else if (Number(args[0]) === 04) {
reply('KL-04= Alappuzha 1989 Ambalappuzha AS')
} else if (Number(args[0]) === 05) {
reply('KL-05= Kottayam 1989 Kottayam AX')
} else if (Number(args[0]) === 06) {
reply('KL-06= Idukki 1989 Idukki L')
} else if (Number(args[0]) === 07) {
reply('KL-07= Ernakulam 1989 Kanayannur CW')
} else if (Number(args[0]) === 08) {
reply('KL-08= Thrissur 1989 Thrissur BX')
} else if (Number(args[0]) === 09) {
reply('KL-09= Palakkad 1989 Palakkad AU')
} else if (Number(args[0]) === 10) {
reply('KL-10= Malappuram 1989 Eranad BF')
} else if (Number(args[0]) === 11) {
reply('KL-11= Kozhikode 1989 Kozhikode BU')
} else if (Number(args[0]) === 12) {
reply('KL-12= Wayanad 1989 Vythiri N')
} else if (Number(args[0]) === 13) {
reply('KL-13= Kannur 1989 Kannur AT')
} else if (Number(args[0]) === 14) {
reply('KL-14= Kasaragod 1989 Kasaragod, Manjeswar AA')
} else if (Number(args[0]) === 15) {
reply('KL-15= Registered in Thiruvananthapuram for KSRTC 1989 Thiruvananthapuram A')
} else if (Number(args[0]) === 16) {
reply('KL-16= Attingal in Thiruvananthapuram District 2002 Chirayinkeezhu Y')
} else if (Number(args[0]) === 17) {
reply('KL-17= Muvattupuzha in Ernakulam District 2002 Muvattupuzha V')
} else if (Number(args[0]) === 18) {
reply('KL-18= Vadakara in Kozhikode District 2002 Kozhikode')
} else if (Number(args[0]) === 19) {
reply('KL-19= Parassala 2006 Neyyattinkara Thiruvananthapuram M')
} else if (Number(args[0]) === 20) {
reply('KL-20= Neyyattinkara 2006 Neyyattinkara Thiruvananthapuram Q')
} else if (Number(args[0]) === 21) {
reply('KL-21= Nedumangad 2006 Nedumangad Thiruvananthapuram V')
} else if (Number(args[0]) === 22) {
reply('KL-22= Kazhakoottam 2006 Thiruvananthapuram Thiruvananthapuram P')
} else if (Number(args[0]) === 23) {
reply('KL-23= Karunagappalli 2006 Karunagappalli Kollam T')
} else if (Number(args[0]) === 24) {
reply('KL-24= Kottarakkara 2006 Kottarakkara Kollam U')
} else if (Number(args[0]) === 25) {
reply('KL-25= Punalur 2006 Punalur Kollam P')
} else if (Number(args[0]) === 26) {
reply('KL-26= Adoor 2006 Adoor Pathanamthitta M')
} else if (Number(args[0]) === 27) {
reply('KL-27= Thiruvalla 2006 Thiruvalla Pathanamthitta K')
} else if (Number(args[0]) === 28) {
reply('KL-28= Mallappally 2006 Mallappally Pathanamthitta E')
} else if (Number(args[0]) === 29) {
reply('KL-29= Kayamkulam 2006 Karthikappally Alappuzha S')
} else if (Number(args[0]) === 30) {
reply('KL-30= Chengannur 2006 Chengannur Alappuzha J')
} else if (Number(args[0]) === 31) {
reply('KL-31= Mavelikkara 2006 Mavelikkara Alappuzha Q')
} else if (Number(args[0]) === 32) {
reply('KL-32= Cherthala 2006 Cherthala Alappuzha R')
} else if (Number(args[0]) === 33) {
reply('KL-33= Changanassery 2006 Changanassery Kottayam N')
} else if (Number(args[0]) === 34) {
reply('KL-34= Kanjirappally 2006 Kanjirappally Kottayam G')
} else if (Number(args[0]) === 35) {
reply('KL-35= Pala 2006 Meenachil Kottayam K')
} else if (Number(args[0]) === 36) {
reply('KL-36= Vaikom 2006 Vaikom Kottayam J')
} else if (Number(args[0]) === 37) {
reply('KL-37= Vandiperiyar 2006 Peerumed Idukki E')
} else if (Number(args[0]) === 38) {
reply('KL-38= Thodupuzha 2006 Thodupuzha Idukki J')
} else if (Number(args[0]) === 39) {
reply('KL-39= Thripunithura 2006 Kanayannur Ernakulam R')
} else if (Number(args[0]) === 40) {
reply('KL-40= Perumbavoor 2006 Kunnathunad Ernakulam S')
} else if (Number(args[0]) === 41) {
reply('KL-41= Aluva 2006 Aluva Ernakulam R')
} else if (Number(args[0]) === 42) {
reply('KL-42= North Paravur 2006 North Paravur Ernakulam T')
} else if (Number(args[0]) === 43) {
reply('KL-43= Mattancherry 2006 Kochi Ernakulam N')
} else if (Number(args[0]) === 44) {
reply('KL-44= Kothamangalam 2006 Kothamangalam Ernakulam G')
} else if (Number(args[0]) === 45) {
reply('KL-45= Irinjalakuda 2006 Mukundapuram Thrissur U')
} else if (Number(args[0]) === 46) {
reply('KL-46= Guruvayur 2006 Chavakkad Thrissur AA')
} else if (Number(args[0]) === 47) {
reply('KL-47= Kodungalloor 2006 Kodungalloor Thrissur K')
} else if (Number(args[0]) === 48) {
reply('KL-48= Wadakkanchery 2006 Thalappilly, Kunnamkulam Thrissur Q')
} else if (Number(args[0]) === 49) {
reply('KL-49= Alathur 2006 Alathur Palakkad M')
} else if (Number(args[0]) === 50) {
reply('KL-50= Mannarkkad 2006 Mannarkkad Palakkad J')
} else if (Number(args[0]) === 51) {
reply('KL-51= Ottappalam 2006 Ottappalam Palakkad M')
} else if (Number(args[0]) === 52) {
reply('KL-52= Pattambi 2006 Pattambi Palakkad R')
} else if (Number(args[0]) === 53) {
reply('KL-53= Perinthalmanna 2006 Perinthalmanna Malappuram R')
} else if (Number(args[0]) === 54) {
reply('KL-54= Ponnani 2006 Ponnani Malappuram M')
} else if (Number(args[0]) === 55) {
reply('KL-55= Tirur 2006 Tirur Malappuram AD')
} else if (Number(args[0]) === 56) {
reply('KL-56= Koyilandy 2006 Koyilandy Kozhikode X')
} else if (Number(args[0]) === 57) {
reply('KL-57= Koduvally 2006 Thamarassery Kozhikode W')
} else if (Number(args[0]) === 58) {
reply('KL-58= Thalassery 2006 Thalassery Kannur AE')
} else if (Number(args[0]) === 59) {
reply('KL-59= Thaliparamba 2006 Thaliparamba Kannur X')
} else if (Number(args[0]) === 60) {
reply('KL-60= Kanhangad 2006 Hosdurg Kasargod S')
} else if (Number(args[0]) === 61) {
reply('KL-61= Kunnathur 2011 Kunnathur Kollam F')
} else if (Number(args[0]) === 62) {
reply('KL-62= Ranni 2011 Ranni Pathanamthitta E')
} else if (Number(args[0]) === 63) {
reply('KL-63= Angamaly 2011 Aluva Ernakulam H')
} else if (Number(args[0]) === 64) {
reply('KL-64= Chalakkudy 2011 Chalakkudy Thrissur J')
} else if (Number(args[0]) === 65) {
reply('KL-65= Tirurangadi 2011 Tirurangadi Malappuram Q')
} else if (Number(args[0]) === 66) {
reply('KL-66= Kuttanadu 2013 Kuttanadu Alappuzha C')
} else if (Number(args[0]) === 67) {
reply('KL-67= Uzhavoor 2013 Meenachil, Vaikom Kottayam C')
} else if (Number(args[0]) === 68) {
reply('KL-68= Devikulam 2013 Devikulam Idukki B')
} else if (Number(args[0]) === 69) {
reply('KL-69= Udumbanchola 2013 Udumbanchola Idukki C')
} else if (Number(args[0]) === 70) {
reply('KL-70= Chittur 2013 Chittur Palakkad F')
} else if (Number(args[0]) === 71) {
reply('KL-71= Nilambur 2013 Nilambur Malappuram H')
} else if (Number(args[0]) === 72) {
reply('KL-72= Mananthavady 2013 Mananthavady Wayanad D')
} else if (Number(args[0]) === 73) {
reply('KL-73= Sulthan Bathery 2013 Sulthan Bathery Wayanad D')
} else if (Number(args[0]) === 74) {
reply('KL-74= Kattakkada 2018 Kattakkada Thiruvananthapuram B')
} else if (Number(args[0]) === 75) {
reply('KL-75= Thriprayar 2018 Chavakkad Thrissur B')
} else if (Number(args[0]) === 76) {
reply('KL-76= Nanmanda 2018 Koyilandy Kozhikode B')
} else if (Number(args[0]) === 77) {
reply('KL-77= Perambra 2018 Koyilandy Kozhikode B')
} else if (Number(args[0]) === 78) {
reply('KL-78= Iritty 2018 Iritty Kannur B')
} else if (Number(args[0]) === 79) {
reply('KL-79= Vellarikundu 2018 Vellarikundu Kasargod *')
} else if (Number(args[0]) === 80) {
reply('KL-80= Pathanapuram 2020 Pathanapuram Kollam *')
} else if (Number(args[0]) === 81) {
reply('KL-81= Varkala 2020 Varkala Thiruvananthapuram *')
} else if (Number(args[0]) === 82) {
reply('KL-82= Chadayamangalam 2020 Kottarakkara Kollam *')
} else if (Number(args[0]) === 83) {
reply('KL-83= Konni 2020 Konni Pathanamthitta *')
} else if (Number(args[0]) === 84) {
reply('KL-84= Kondotty 2020 Kondotty Malappuram *')
} else if (Number(args[0]) === 85) {
reply('KL-85= Ramanattukara (Feroke) 2020 Kozhikode Kozhikode *')
} else if (Number(args[0]) === 86) {
reply('KL-86= Payyannur 2020 Payyannur Kannur *')
} else if (Number(args[0]) === 93) {
reply('KL-93= Manjeri 2020 Eranad Malappuram *')
} else if (Number(args[0]) === 99) {
reply('KL-99= Higher Authority 2020 Thiruvananthapuram')
} else {
reply('\`\`\`\nhey kid\nplease 🥺 type correctly\n\`\`\`')
}
break
case '+':
if (args.length < 1) return reply('what plus 😲🧘')
if (Number(args[0]) === 93) {
reply('\`\`\` countryName : Afghanistan \n iso2 : AF \n iso3 : AFG \n phoneCode : +93 \`\`\`')
} else if (Number(args[0]) === 355) {
reply('\`\`\` countryName : Albania \n iso2 : AL \n iso3 : ALB \n phoneCode : +355 \`\`\`')
} else if (Number(args[0]) === 213) {
reply('\`\`\` countryName : Algeria \n iso2 : DZ \n iso3 : DZA \n phoneCode : +213 \`\`\`')
} else if (Number(args[0]) === 1684) {
reply('\`\`\` countryName : American Samoa \n iso2 : AS \n iso3 : ASM \n phoneCode : +1 684 \`\`\`')
} else if (Number(args[0]) === 376) {
reply('\`\`\` countryName : Andorra \n iso2 : AD \n iso3 : AND \n phoneCode : +376 \`\`\`')
} else if (Number(args[0]) === 244) {
reply('\`\`\` countryName : Angola \n iso2 : AO \n iso3 : AGO \n phoneCode : +244 \`\`\`')
} else if (Number(args[0]) === 1264) {
reply('\`\`\` countryName : Anguilla \n iso2 : AI \n iso3 : AIA \n phoneCode : +1 264 \`\`\`')
} else if (Number(args[0]) === 672) {
reply('\`\`\` countryName : Antarctica \n iso2 : AQ \n iso3 : ATA \n phoneCode : +672 \`\`\`')
} else if (Number(args[0]) === 1268) {
reply('\`\`\` countryName : Antigua and Barbuda \n iso2 : AG \n iso3 : ATG \n phoneCode : +1 268 \`\`\`')
} else if (Number(args[0]) === 54) {
reply('\`\`\` countryName : Argentina \n iso2 : AR \n iso3 : ARG \n phoneCode : +54 \`\`\`')
} else if (Number(args[0]) === 374) {
reply('\`\`\` countryName : Armenia \n iso2 : AM \n iso3 : ARM \n phoneCode : +374 \`\`\`')
} else if (Number(args[0]) === 297) {
reply('\`\`\` countryName : Aruba \n iso2 : AW \n iso3 : ABW \n phoneCode : +297 \`\`\`')
} else if (Number(args[0]) === 61) {
reply('\`\`\` countryName : Australia \n iso2 : AU \n iso3 : AUS \n phoneCode : +61 \`\`\`')
} else if (Number(args[0]) === 43) {
reply('\`\`\` countryName : Austria \n iso2 : AT \n iso3 : AUT \n phoneCode : +43 \`\`\`')
} else if (Number(args[0]) === 994) {
reply('\`\`\` countryName : Azerbaijan \n iso2 : AZ \n iso3 : AZE \n phoneCode : +994 \`\`\`')
} else if (Number(args[0]) === 1242) {
reply('\`\`\` countryName : Bahamas \n iso2 : BS \n iso3 : BHS \n phoneCode : +1 242 \`\`\`')
} else if (Number(args[0]) === 973) {
reply('\`\`\` countryName : Bahrain \n iso2 : BH \n iso3 : BHR \n phoneCode : +973 \`\`\`')
} else if (Number(args[0]) === 880) {
reply('\`\`\` countryName : Bangladesh \n iso2 : BD \n iso3 : BGD \n phoneCode : +880 \`\`\`')
} else if (Number(args[0]) === 1246) {
reply('\`\`\` countryName : Barbados \n iso2 : BB \n iso3 : BRB \n phoneCode : +1 246 \`\`\`')
} else if (Number(args[0]) === 375) {
reply('\`\`\` countryName : Belarus \n iso2 : BY \n iso3 : BLR \n phoneCode : +375 \`\`\`')
} else if (Number(args[0]) === 32) {
reply('\`\`\` countryName : Belgium \n iso2 : BE \n iso3 : BEL \n phoneCode : +32 \`\`\`')
} else if (Number(args[0]) === 501) {
reply('\`\`\` countryName : Belize \n iso2 : BZ \n iso3 : BLZ \n phoneCode : +501 \`\`\`')
} else if (Number(args[0]) === 229) {
reply('\`\`\` countryName : Benin \n iso2 : BJ \n iso3 : BEN \n phoneCode : +229 \`\`\`')
} else if (Number(args[0]) === 1441) {
reply('\`\`\` countryName : Bermuda \n iso2 : BM \n iso3 : BMU \n phoneCode : +1 441 \`\`\`')
} else if (Number(args[0]) === 975) {
reply('\`\`\` countryName : Bhutan \n iso2 : BT \n iso3 : BTN \n phoneCode : +975 \`\`\`')
} else if (Number(args[0]) === 591) {
reply('\`\`\` countryName : Bolivia \n iso2 : BO \n iso3 : BOL \n phoneCode : +591 \`\`\`')
} else if (Number(args[0]) === 387) {
reply('\`\`\` countryName : Bosnia and Herzegovina \n iso2 : BA \n iso3 : BIH \n phoneCode : +387 \`\`\`')
} else if (Number(args[0]) === 267) {
reply('\`\`\` countryName : Botswana \n iso2 : BW \n iso3 : BWA \n phoneCode : +267 \`\`\`')
} else if (Number(args[0]) === 55) {
reply('\`\`\` countryName : Brazil \n iso2 : BR \n iso3 : BRA \n phoneCode : +55 \`\`\`')
} else if (Number(args[0]) === 1284) {
reply('\`\`\` countryName : British Virgin Islands \n iso2 : VG \n iso3 : VGB \n phoneCode : +1 284 \`\`\`')
} else if (Number(args[0]) === 673) {
reply('\`\`\` countryName : Brunei \n iso2 : BN \n iso3 : BRN \n phoneCode : +673 \`\`\`')
} else if (Number(args[0]) === 359) {
reply('\`\`\` countryName : Bulgaria \n iso2 : BG \n iso3 : BGR \n phoneCode : +359 \`\`\`')
} else if (Number(args[0]) === 226) {
reply('\`\`\` countryName : Burkina Faso \n iso2 : BF \n iso3 : BFA \n phoneCode : +226 \`\`\`')
} else if (Number(args[0]) === 95) {
reply('\`\`\` countryName : Burma : Myanmar \n iso2 : MM \n iso3 : MMR \n phoneCode : +95 \`\`\`')
} else if (Number(args[0]) === 257) {
reply('\`\`\` countryName : Burundi \n iso2 : BI \n iso3 : BDI \n phoneCode : +257 \`\`\`')
} else if (Number(args[0]) === 855) {
reply('\`\`\` countryName : Cambodia \n iso2 : KH \n iso3 : KHM \n phoneCode : +855 \`\`\`')
} else if (Number(args[0]) === 237) {
reply('\`\`\` countryName : Cameroon \n iso2 : CM \n iso3 : CMR \n phoneCode : +237 \`\`\`')
} else if (Number(args[0]) === 1) {
reply('\`\`\` countryName : Canada \n iso2 : CA \n iso3 : CAN \n phoneCode : +1 \n countryName : Puerto Rico \n iso2 : PR \n iso3 : PRI \n phoneCode : +1 \n countryName : United States \n iso2 : US \n iso3 : USA \n phoneCode : +1 \`\`\`')
} else if (Number(args[0]) === 238) {
reply('\`\`\` countryName : Cape Verde \n iso2 : CV \n iso3 : CPV \n phoneCode : +238 \`\`\`')
} else if (Number(args[0]) === 1345) {
reply('\`\`\` countryName : Cayman Islands \n iso2 : KY \n iso3 : CYM \n phoneCode : +1 345 \`\`\`')
} else if (Number(args[0]) === 236) {
reply('\`\`\` countryName : Central African Republic \n iso2 : CF \n iso3 : CAF \n phoneCode : +236 \`\`\`')
} else if (Number(args[0]) === 235) {
reply('\`\`\` countryName : Chad \n iso2 : TD \n iso3 : TCD \n phoneCode : +235 \`\`\`')
} else if (Number(args[0]) === 56) {
reply('\`\`\` countryName : Chile \n iso2 : CL \n iso3 : CHL \n phoneCode : +56 \`\`\`')
} else if (Number(args[0]) === 86) {
reply('\`\`\` countryName : China \n iso2 : CN \n iso3 : CHN \n phoneCode : +86 \`\`\`')
} else if (Number(args[0]) === 61) {
reply('\`\`\` countryName : Cocos Islands \n iso2 : CC \n iso3 : CCK \n phoneCode : +61 \n countryName : Christmas Island \n iso2 : CX \n iso3 : CXR \n phoneCode : +61 \`\`\`')
} else if (Number(args[0]) === 57) {
reply('\`\`\` countryName : Colombia \n iso2 : CO \n iso3 : COL \n phoneCode : +57 \`\`\`')
} else if (Number(args[0]) === 269) {
reply('\`\`\` countryName : Comoros \n iso2 : KM \n iso3 : COM \n phoneCode : +269 \`\`\`')
} else if (Number(args[0]) === 682) {
reply('\`\`\` countryName : Cook Islands \n iso2 : CK \n iso3 : COK \n phoneCode : +682 \`\`\`')
} else if (Number(args[0]) === 506) {
reply('\`\`\` countryName : Costa Rica \n iso2 : CR \n iso3 : CRC \n phoneCode : +506 \`\`\`')
} else if (Number(args[0]) === 385) {
reply('\`\`\` countryName : Croatia \n iso2 : HR \n iso3 : HRV \n phoneCode : +385 \`\`\`')
} else if (Number(args[0]) === 53) {
reply('\`\`\` countryName : Cuba \n iso2 : CU \n iso3 : CUB \n phoneCode : +53 \`\`\`')
} else if (Number(args[0]) === 357) {
reply('\`\`\` countryName : Cyprus \n iso2 : CY \n iso3 : CYP \n phoneCode : +357 \`\`\`')
} else if (Number(args[0]) === 420) {
reply('\`\`\` countryName : Czech Republic \n iso2 : CZ \n iso3 : CZE \n phoneCode : +420 \`\`\`')
} else if (Number(args[0]) === 243) {
reply('\`\`\` countryName : Democratic Republic of the Congo \n iso2 : CD \n iso3 : COD \n phoneCode : +243 \`\`\`')
} else if (Number(args[0]) === 45) {
reply('\`\`\` countryName : Denmark \n iso2 : DK \n iso3 : DNK \n phoneCode : +45 \`\`\`')
} else if (Number(args[0]) === 253) {
reply('\`\`\` countryName : Djibouti \n iso2 : DJ \n iso3 : DJI \n phoneCode : +253 \`\`\`')
} else if (Number(args[0]) === 1767) {
reply('\`\`\` countryName : Dominica \n iso2 : DM \n iso3 : DMA \n phoneCode : +1 767 \`\`\`')
} else if (Number(args[0]) === 1809) {
reply('\`\`\` countryName : Dominican Republic \n iso2 : DO \n iso3 : DOM \n phoneCode : +1 809 \`\`\`')
} else if (Number(args[0]) === 593) {
reply('\`\`\` countryName : Ecuador \n iso2 : EC \n iso3 : ECU \n phoneCode : +593 \`\`\`')
} else if (Number(args[0]) === 20) {
reply('\`\`\` countryName : Egypt \n iso2 : EG \n iso3 : EGY \n phoneCode : +20 \`\`\`')
} else if (Number(args[0]) === 503) {
reply('\`\`\` countryName : El Salvador \n iso2 : SV \n iso3 : SLV \n phoneCode : +503 \`\`\`')
} else if (Number(args[0]) === 240) {
reply('\`\`\` countryName : Equatorial Guinea \n iso2 : GQ \n iso3 : GNQ \n phoneCode : +240 \`\`\`')
} else if (Number(args[0]) === 291) {
reply('\`\`\` countryName : Eritrea \n iso2 : ER \n iso3 : ERI \n phoneCode : +291 \`\`\`')
} else if (Number(args[0]) === 372) {
reply('\`\`\` countryName : Estonia \n iso2 : EE \n iso3 : EST \n phoneCode : +372 \`\`\`')
} else if (Number(args[0]) === 251) {
reply('\`\`\` countryName : Ethiopia \n iso2 : ET \n iso3 : ETH \n phoneCode : +251 \`\`\`')
} else if (Number(args[0]) === 500) {
reply('\`\`\` countryName : Falkland Islands \n iso2 : FK \n iso3 : FLK \n phoneCode : +500 \`\`\`')
} else if (Number(args[0]) === 298) {
reply('\`\`\` countryName : Faroe Islands \n iso2 : FO \n iso3 : FRO \n phoneCode : +298 \`\`\`')
} else if (Number(args[0]) === 679) {
reply('\`\`\` countryName : Fiji \n iso2 : FJ \n iso3 : FJI \n phoneCode : +679 \`\`\`')
} else if (Number(args[0]) === 358) {
reply('\`\`\` countryName : Finland \n iso2 : FI \n iso3 : FIN \n phoneCode : +358 \`\`\`')
} else if (Number(args[0]) === 33) {
reply('\`\`\` countryName : France \n iso2 : FR \n iso3 : FRA \n phoneCode : +33 \`\`\`')
} else if (Number(args[0]) === 689) {
reply('\`\`\` countryName : French Polynesia \n iso2 : PF \n iso3 : PYF \n phoneCode : +689 \`\`\`')
} else if (Number(args[0]) === 241) {
reply('\`\`\` countryName : Gabon \n iso2 : GA \n iso3 : GAB \n phoneCode : +241 \`\`\`')
} else if (Number(args[0]) === 220) {
reply('\`\`\` countryName : Gambia \n iso2 : GM \n iso3 : GMB \n phoneCode : +220 \`\`\`')
} else if (Number(args[0]) === 970) {
reply('\`\`\` countryName : Gaza Strip \n iso2 :  \n iso3 :  \n phoneCode : +970 \`\`\`')
} else if (Number(args[0]) === 995) {
reply('\`\`\` countryName : Georgia \n iso2 : GE \n iso3 : GEO \n phoneCode : +995 \`\`\`')
} else if (Number(args[0]) === 49) {
reply('\`\`\` countryName : Germany \n iso2 : DE \n iso3 : DEU \n phoneCode : +49 \`\`\`')
} else if (Number(args[0]) === 233) {
reply('\`\`\` countryName : Ghana \n iso2 : GH \n iso3 : GHA \n phoneCode : +233 \`\`\`')
} else if (Number(args[0]) === 350) {
reply('\`\`\` countryName : Gibraltar \n iso2 : GI \n iso3 : GIB \n phoneCode : +350 \`\`\`')
} else if (Number(args[0]) === 30) {
reply('\`\`\` countryName : Greece \n iso2 : GR \n iso3 : GRC \n phoneCode : +30 \`\`\`')
} else if (Number(args[0]) === 299) {
reply('\`\`\` countryName : Greenland \n iso2 : GL \n iso3 : GRL \n phoneCode : +299 \`\`\`')
} else if (Number(args[0]) === 1473) {
reply('\`\`\` countryName : Grenada \n iso2 : GD \n iso3 : GRD \n phoneCode : +1 473 \`\`\`')
} else if (Number(args[0]) === 1671) {
reply('\`\`\` countryName : Guam \n iso2 : GU \n iso3 : GUM \n phoneCode : +1 671 \`\`\`')
} else if (Number(args[0]) === 502) {
reply('\`\`\` countryName : Guatemala \n iso2 : GT \n iso3 : GTM \n phoneCode : +502 \`\`\`')
} else if (Number(args[0]) === 224) {
reply('\`\`\` countryName : Guinea \n iso2 : GN \n iso3 : GIN \n phoneCode : +224 \`\`\`')
} else if (Number(args[0]) === 245) {
reply('\`\`\` countryName : GuineaBissau \n iso2 : GW \n iso3 : GNB \n phoneCode : +245 \`\`\`')
} else if (Number(args[0]) === 592) {
reply('\`\`\` countryName : Guyana \n iso2 : GY \n iso3 : GUY \n phoneCode : +592 \`\`\`')
} else if (Number(args[0]) === 509) {
reply('\`\`\` countryName : Haiti \n iso2 : HT \n iso3 : HTI \n phoneCode : +509 \`\`\`')
} else if (Number(args[0]) === 39) {
reply('\`\`\` countryName : Holy See Vatican City \n iso2 : VA \n iso3 : VAT \n phoneCode : +39 \`\`\`')
} else if (Number(args[0]) === 504) {
reply('\`\`\` countryName : Honduras \n iso2 : HN \n iso3 : HND \n phoneCode : +504 \`\`\`')
} else if (Number(args[0]) === 852) {
reply('\`\`\` countryName : Hong Kong \n iso2 : HK \n iso3 : HKG \n phoneCode : +852 \`\`\`')
} else if (Number(args[0]) === 36) {
reply('\`\`\` countryName : Hungary \n iso2 : HU \n iso3 : HUN \n phoneCode : +36 \`\`\`')
} else if (Number(args[0]) === 354) {
reply('\`\`\` countryName : Iceland \n iso2 : IS \n iso3 : IS \n phoneCode : +354 \`\`\`')
} else if (Number(args[0]) === 91) {
reply('\`\`\` countryName : India \n iso2 : IN \n iso3 : IND \n phoneCode : +91 \nella athu ninakku areelle myire\`\`\`')
} else if (Number(args[0]) === 62) {
reply('\`\`\` countryName : Indonesia \n iso2 : ID \n iso3 : IDN \n phoneCode : +62 \`\`\`')
} else if (Number(args[0]) === 98) {
reply('\`\`\` countryName : Iran \n iso2 : IR \n iso3 : IRN \n phoneCode : +98 \`\`\`')
} else if (Number(args[0]) === 964) {
reply('\`\`\` countryName : Iraq \n iso2 : IQ \n iso3 : IRQ \n phoneCode : +964 \`\`\`')
} else if (Number(args[0]) === 353) {
reply('\`\`\` countryName : Ireland \n iso2 : IE \n iso3 : IRL \n phoneCode : +353 \`\`\`')
} else if (Number(args[0]) === 44) {
reply('\`\`\` countryName : Isle of Man \n iso2 : IM \n iso3 : IMN \n phoneCode : +44 \`\`\`')
} else if (Number(args[0]) === 972) {
reply('\`\`\` countryName : Israel \n iso2 : IL \n iso3 : ISR \n phoneCode : +972 \`\`\`')
} else if (Number(args[0]) === 39) {
reply('\`\`\` countryName : Italy \n iso2 : IT \n iso3 : ITA \n phoneCode : +39 \`\`\`')
} else if (Number(args[0]) === 225) {
reply('\`\`\` countryName : Ivory Coast \n iso2 : CI \n iso3 : CIV \n phoneCode : +225 \`\`\`')
} else if (Number(args[0]) === 1876) {
reply('\`\`\` countryName : Jamaica \n iso2 : JM \n iso3 : JAM \n phoneCode : +1 876 \`\`\`')
} else if (Number(args[0]) === 81) {
reply('\`\`\` countryName : Japan \n iso2 : JP \n iso3 : JPN \n phoneCode : +81 \`\`\`')
} else if (Number(args[0]) === 962) {
reply('\`\`\` countryName : Jordan \n iso2 : JO \n iso3 : JOR \n phoneCode : +962 \`\`\`')
} else if (Number(args[0]) === 7) {
reply('\`\`\` countryName : Kazakhstan \n iso2 : KZ \n iso3 : KAZ \n phoneCode : +7\n countryName : Russia \n iso2 : RU \n iso3 : RUS \n phoneCode : +7 \`\`\`')
} else if (Number(args[0]) === 254) {
reply('\`\`\` countryName : Kenya \n iso2 : KE \n iso3 : KEN \n phoneCode : +254 \`\`\`')
} else if (Number(args[0]) === 686) {
reply('\`\`\` countryName : Kiribati \n iso2 : KI \n iso3 : KIR \n phoneCode : +686 \`\`\`')
} else if (Number(args[0]) === 383) {
reply('\`\`\` countryName : Kosovo \n iso2 :  \n iso3 :  \n phoneCode : +383 \`\`\`')
} else if (Number(args[0]) === 965) {
reply('\`\`\` countryName : Kuwait \n iso2 : KW \n iso3 : KWT \n phoneCode : +965 \`\`\`')
} else if (Number(args[0]) === 996) {
reply('\`\`\` countryName : Kyrgyzstan \n iso2 : KG \n iso3 : KGZ \n phoneCode : +996 \`\`\`')
} else if (Number(args[0]) === 856) {
reply('\`\`\` countryName : Laos \n iso2 : LA \n iso3 : LAO \n phoneCode : +856 \`\`\`')
} else if (Number(args[0]) === 371) {
reply('\`\`\` countryName : Latvia \n iso2 : LV \n iso3 : LVA \n phoneCode : +371 \`\`\`')
} else if (Number(args[0]) === 961) {
reply('\`\`\` countryName : Lebanon \n iso2 : LB \n iso3 : LBN \n phoneCode : +961 \`\`\`')
} else if (Number(args[0]) === 266) {
reply('\`\`\` countryName : Lesotho \n iso2 : LS \n iso3 : LSO \n phoneCode : +266 \`\`\`')
} else if (Number(args[0]) === 231) {
reply('\`\`\` countryName : Liberia \n iso2 : LR \n iso3 : LBR \n phoneCode : +231 \`\`\`')
} else if (Number(args[0]) === 218) {
reply('\`\`\` countryName : Libya \n iso2 : LY \n iso3 : LBY \n phoneCode : +218 \`\`\`')
} else if (Number(args[0]) === 423) {
reply('\`\`\` countryName : Liechtenstein \n iso2 : LI \n iso3 : LIE \n phoneCode : +423 \`\`\`')
} else if (Number(args[0]) === 370) {
reply('\`\`\` countryName : Lithuania \n iso2 : LT \n iso3 : LTU \n phoneCode : +370 \`\`\`')
} else if (Number(args[0]) === 352) {
reply('\`\`\` countryName : Luxembourg \n iso2 : LU \n iso3 : LUX \n phoneCode : +352 \`\`\`')
} else if (Number(args[0]) === 853) {
reply('\`\`\` countryName : Macau \n iso2 : MO \n iso3 : MAC \n phoneCode : +853 \`\`\`')
} else if (Number(args[0]) === 389) {
reply('\`\`\` countryName : Macedonia \n iso2 : MK \n iso3 : MKD \n phoneCode : +389 \`\`\`')
} else if (Number(args[0]) === 261) {
reply('\`\`\` countryName : Madagascar \n iso2 : MG \n iso3 : MDG \n phoneCode : +261 \`\`\`')
} else if (Number(args[0]) === 265) {
reply('\`\`\` countryName : Malawi \n iso2 : MW \n iso3 : MWI \n phoneCode : +265 \`\`\`')
} else if (Number(args[0]) === 60) {
reply('\`\`\` countryName : Malaysia \n iso2 : MY \n iso3 : MYS \n phoneCode : +60 \`\`\`')
} else if (Number(args[0]) === 960) {
reply('\`\`\` countryName : Maldives \n iso2 : MV \n iso3 : MDV \n phoneCode : +960 \`\`\`')
} else if (Number(args[0]) === 223) {
reply('\`\`\` countryName : Mali \n iso2 : ML \n iso3 : MLI \n phoneCode : +223 \`\`\`')
} else if (Number(args[0]) === 356) {
reply('\`\`\` countryName : Malta \n iso2 : MT \n iso3 : MLT \n phoneCode : +356 \`\`\`')
} else if (Number(args[0]) === 692) {
reply('\`\`\` countryName : Marshall Islands \n iso2 : MH \n iso3 : MHL \n phoneCode : +692 \`\`\`')
} else if (Number(args[0]) === 222) {
reply('\`\`\` countryName : Mauritania \n iso2 : MR \n iso3 : MRT \n phoneCode : +222 \`\`\`')
} else if (Number(args[0]) === 230) {
reply('\`\`\` countryName : Mauritius \n iso2 : MU \n iso3 : MUS \n phoneCode : +230 \`\`\`')
} else if (Number(args[0]) === 262) {
reply('\`\`\` countryName : Mayotte \n iso2 : YT \n iso3 : MYT \n phoneCode : +262 \`\`\`')
} else if (Number(args[0]) === 52) {
reply('\`\`\` countryName : Mexico \n iso2 : MX \n iso3 : MEX \n phoneCode : +52 \`\`\`')
} else if (Number(args[0]) === 691) {
reply('\`\`\` countryName : Micronesia \n iso2 : FM \n iso3 : FSM \n phoneCode : +691 \`\`\`')
} else if (Number(args[0]) === 373) {
reply('\`\`\` countryName : Moldova \n iso2 : MD \n iso3 : MDA \n phoneCode : +373 \`\`\`')
} else if (Number(args[0]) === 377) {
reply('\`\`\` countryName : Monaco \n iso2 : MC \n iso3 : MCO \n phoneCode : +377 \`\`\`')
} else if (Number(args[0]) === 976) {
reply('\`\`\` countryName : Mongolia \n iso2 : MN \n iso3 : MNG \n phoneCode : +976 \`\`\`')
} else if (Number(args[0]) === 382) {
reply('\`\`\` countryName : Montenegro \n iso2 : ME \n iso3 : MNE \n phoneCode : +382 \`\`\`')
} else if (Number(args[0]) === 1664) {
reply('\`\`\` countryName : Montserrat \n iso2 : MS \n iso3 : MSR \n phoneCode : +1 664 \`\`\`')
} else if (Number(args[0]) === 212) {
reply('\`\`\` countryName : Morocco \n iso2 : MA \n iso3 : MAR \n phoneCode : +212 \`\`\`')
} else if (Number(args[0]) === 258) {
reply('\`\`\` countryName : Mozambique \n iso2 : MZ \n iso3 : MOZ \n phoneCode : +258 \`\`\`')
} else if (Number(args[0]) === 264) {
reply('\`\`\` countryName : Namibia \n iso2 : NA \n iso3 : NAM \n phoneCode : +264 \`\`\`')
} else if (Number(args[0]) === 674) {
reply('\`\`\` countryName : Nauru \n iso2 : NR \n iso3 : NRU \n phoneCode : +674 \`\`\`')
} else if (Number(args[0]) === 977) {
reply('\`\`\` countryName : Nepal \n iso2 : NP \n iso3 : NPL \n phoneCode : +977 \`\`\`')
} else if (Number(args[0]) === 31) {
reply('\`\`\` countryName : Netherlands \n iso2 : NL \n iso3 : NLD \n phoneCode : +31 \`\`\`')
} else if (Number(args[0]) === 599) {
reply('\`\`\` countryName : Netherlands Antilles \n iso2 : AN \n iso3 : ANT \n phoneCode : +599 \`\`\`')
} else if (Number(args[0]) === 687) {
reply('\`\`\` countryName : New Caledonia \n iso2 : NC \n iso3 : NCL \n phoneCode : +687 \`\`\`')
} else if (Number(args[0]) === 64) {
reply('\`\`\` countryName : New Zealand \n iso2 : NZ \n iso3 : NZL \n phoneCode : +64 \`\`\`')
} else if (Number(args[0]) === 505) {
reply('\`\`\` countryName : Nicaragua \n iso2 : NI \n iso3 : NIC \n phoneCode : +505 \`\`\`')
} else if (Number(args[0]) === 227) {
reply('\`\`\` countryName : Niger \n iso2 : NE \n iso3 : NER \n phoneCode : +227 \`\`\`')
} else if (Number(args[0]) === 234) {
reply('\`\`\` countryName : Nigeria \n iso2 : NG \n iso3 : NGA \n phoneCode : +234 \`\`\`')
} else if (Number(args[0]) === 683) {
reply('\`\`\` countryName : Niue \n iso2 : NU \n iso3 : NIU \n phoneCode : +683 \`\`\`')
} else if (Number(args[0]) === 672) {
reply('\`\`\` countryName : Norfolk Island \n iso2 :  \n iso3 : NFK \n phoneCode : +672 \`\`\`')
} else if (Number(args[0]) === 850) {
reply('\`\`\` countryName : North Korea \n iso2 : KP \n iso3 : PRK \n phoneCode : +850 \`\`\`')
} else if (Number(args[0]) === 1670) {
reply('\`\`\` countryName : Northern Mariana Islands \n iso2 : MP \n iso3 : MNP \n phoneCode : +1 670 \`\`\`')
} else if (Number(args[0]) === 47) {
reply('\`\`\` countryName : Norway \n iso2 : NO \n iso3 : NOR \n phoneCode : +47 \`\`\`')
} else if (Number(args[0]) === 968) {
reply('\`\`\` countryName : Oman \n iso2 : OM \n iso3 : OMN \n phoneCode : +968 \`\`\`')
} else if (Number(args[0]) === 92) {
reply('\`\`\` countryName : Pakistan \n iso2 : PK \n iso3 : PAK \n phoneCode : +92 \`\`\`')
} else if (Number(args[0]) === 680) {
reply('\`\`\` countryName : Palau \n iso2 : PW \n iso3 : PLW \n phoneCode : +680 \`\`\`')
} else if (Number(args[0]) === 507) {
reply('\`\`\` countryName : Panama \n iso2 : PA \n iso3 : PAN \n phoneCode : +507 \`\`\`')
} else if (Number(args[0]) === 675) {
reply('\`\`\` countryName : Papua New Guinea \n iso2 : PG \n iso3 : PNG \n phoneCode : +675 \`\`\`')
} else if (Number(args[0]) === 595) {
reply('\`\`\` countryName : Paraguay \n iso2 : PY \n iso3 : PRY \n phoneCode : +595 \`\`\`')
} else if (Number(args[0]) === 51) {
reply('\`\`\` countryName : Peru \n iso2 : PE \n iso3 : PER \n phoneCode : +51 \`\`\`')
} else if (Number(args[0]) === 63) {
reply('\`\`\` countryName : Philippines \n iso2 : PH \n iso3 : PHL \n phoneCode : +63 \`\`\`')
} else if (Number(args[0]) === 870) {
reply('\`\`\` countryName : Pitcairn Islands \n iso2 : PN \n iso3 : PCN \n phoneCode : +870 \`\`\`')
} else if (Number(args[0]) === 48) {
reply('\`\`\` countryName : Poland \n iso2 : PL \n iso3 : POL \n phoneCode : +48 \`\`\`')
} else if (Number(args[0]) === 351) {
reply('\`\`\` countryName : Portugal \n iso2 : PT \n iso3 : PRT \n phoneCode : +351 \`\`\`')
} else if (Number(args[0]) === 974) {
reply('\`\`\` countryName : Qatar \n iso2 : QA \n iso3 : QAT \n phoneCode : +974 \`\`\`')
} else if (Number(args[0]) === 242) {
reply('\`\`\` countryName : Republic of the Congo \n iso2 : CG \n iso3 : COG \n phoneCode : +242 \`\`\`')
} else if (Number(args[0]) === 40) {
reply('\`\`\` countryName : Romania \n iso2 : RO \n iso3 : ROU \n phoneCode : +40 \`\`\`')
} else if (Number(args[0]) === 250) {
reply('\`\`\` countryName : Rwanda \n iso2 : RW \n iso3 : RWA \n phoneCode : +250 \`\`\`')
} else if (Number(args[0]) === 590) {
reply('\`\`\` countryName : Saint Barthelemy \n iso2 : BL \n iso3 : BLM \n phoneCode : +590 \`\`\`')
} else if (Number(args[0]) === 290) {
reply('\`\`\` countryName : Saint Helena \n iso2 : SH \n iso3 : SHN \n phoneCode : +290 \`\`\`')
} else if (Number(args[0]) === 1869) {
reply('\`\`\` countryName : Saint Kitts and Nevis \n iso2 : KN \n iso3 : KNA \n phoneCode : +1 869 \`\`\`')
} else if (Number(args[0]) === 1758) {
reply('\`\`\` countryName : Saint Lucia \n iso2 : LC \n iso3 : LCA \n phoneCode : +1 758 \`\`\`')
} else if (Number(args[0]) === 1599) {
reply('\`\`\` countryName : Saint Martin \n iso2 : MF \n iso3 : MAF \n phoneCode : +1 599 \`\`\`')
} else if (Number(args[0]) === 508) {
reply('\`\`\` countryName : Saint Pierre and Miquelon \n iso2 : PM \n iso3 : SPM \n phoneCode : +508 \`\`\`')
} else if (Number(args[0]) === 1784) {
reply('\`\`\` countryName : Saint Vincent and the Grenadines \n iso2 : VC \n iso3 : VCT \n phoneCode : +1 784 \`\`\`')
} else if (Number(args[0]) === 685) {
reply('\`\`\` countryName : Samoa \n iso2 : WS \n iso3 : WSM \n phoneCode : +685 \`\`\`')
} else if (Number(args[0]) === 378) {
reply('\`\`\` countryName : San Marino \n iso2 : SM \n iso3 : SMR \n phoneCode : +378 \`\`\`')
} else if (Number(args[0]) === 239) {
reply('\`\`\` countryName : Sao Tome and Principe \n iso2 : ST \n iso3 : STP \n phoneCode : +239 \`\`\`')
} else if (Number(args[0]) === 966) {
reply('\`\`\` countryName : Saudi Arabia \n iso2 : SA \n iso3 : SAU \n phoneCode : +966 \`\`\`')
} else if (Number(args[0]) === 221) {
reply('\`\`\` countryName : Senegal \n iso2 : SN \n iso3 : SEN \n phoneCode : +221 \`\`\`')
} else if (Number(args[0]) === 381) {
reply('\`\`\` countryName : Serbia \n iso2 : RS \n iso3 : SRB \n phoneCode : +381 \`\`\`')
} else if (Number(args[0]) === 248) {
reply('\`\`\` countryName : Seychelles \n iso2 : SC \n iso3 : SYC \n phoneCode : +248 \`\`\`')
} else if (Number(args[0]) === 232) {
reply('\`\`\` countryName : Sierra Leone \n iso2 : SL \n iso3 : SLE \n phoneCode : +232 \`\`\`')
} else if (Number(args[0]) === 65) {
reply('\`\`\` countryName : Singapore \n iso2 : SG \n iso3 : SGP \n phoneCode : +65 \`\`\`')
} else if (Number(args[0]) === 421) {
reply('\`\`\` countryName : Slovakia \n iso2 : SK \n iso3 : SVK \n phoneCode : +421 \`\`\`')
} else if (Number(args[0]) === 386) {
reply('\`\`\` countryName : Slovenia \n iso2 : SI \n iso3 : SVN \n phoneCode : +386 \`\`\`')
} else if (Number(args[0]) === 677) {
reply('\`\`\` countryName : Solomon Islands \n iso2 : SB \n iso3 : SLB \n phoneCode : +677 \`\`\`')
} else if (Number(args[0]) === 252) {
reply('\`\`\` countryName : Somalia \n iso2 : SO \n iso3 : SOM \n phoneCode : +252 \`\`\`')
} else if (Number(args[0]) === 27) {
reply('\`\`\` countryName : South Africa \n iso2 : ZA \n iso3 : ZAF \n phoneCode : +27 \`\`\`')
} else if (Number(args[0]) === 82) {
reply('\`\`\` countryName : South Korea \n iso2 : KR \n iso3 : KOR \n phoneCode : +82 \`\`\`')
} else if (Number(args[0]) === 34) {
reply('\`\`\` countryName : Spain \n iso2 : ES \n iso3 : ESP \n phoneCode : +34 \`\`\`')
} else if (Number(args[0]) === 94) {
reply('\`\`\` countryName : Sri Lanka \n iso2 : LK \n iso3 : LKA \n phoneCode : +94 \`\`\`')
} else if (Number(args[0]) === 249) {
reply('\`\`\` countryName : Sudan \n iso2 : SD \n iso3 : SDN \n phoneCode : +249 \`\`\`')
} else if (Number(args[0]) === 597) {
reply('\`\`\` countryName : Suriname \n iso2 : SR \n iso3 : SUR \n phoneCode : +597 \`\`\`')
} else if (Number(args[0]) === 268) {
reply('\`\`\` countryName : Swaziland \n iso2 : SZ \n iso3 : SWZ \n phoneCode : +268 \`\`\`')
} else if (Number(args[0]) === 46) {
reply('\`\`\` countryName : Sweden \n iso2 : SE \n iso3 : SWE \n phoneCode : +46 \`\`\`')
} else if (Number(args[0]) === 41) {
reply('\`\`\` countryName : Switzerland \n iso2 : CH \n iso3 : CHE \n phoneCode : +41 \`\`\`')
} else if (Number(args[0]) === 963) {
reply('\`\`\` countryName : Syria \n iso2 : SY \n iso3 : SYR \n phoneCode : +963 \`\`\`')
} else if (Number(args[0]) === 886) {
reply('\`\`\` countryName : Taiwan \n iso2 : TW \n iso3 : TWN \n phoneCode : +886 \`\`\`')
} else if (Number(args[0]) === 992) {
reply('\`\`\` countryName : Tajikistan \n iso2 : TJ \n iso3 : TJK \n phoneCode : +992 \`\`\`')
} else if (Number(args[0]) === 255) {
reply('\`\`\` countryName : Tanzania \n iso2 : TZ \n iso3 : TZA \n phoneCode : +255 \`\`\`')
} else if (Number(args[0]) === 66) {
reply('\`\`\` countryName : Thailand \n iso2 : TH \n iso3 : THA \n phoneCode : +66 \`\`\`')
} else if (Number(args[0]) === 670) {
reply('\`\`\` countryName : TimorLeste \n iso2 : TL \n iso3 : TLS \n phoneCode : +670 \`\`\`')
} else if (Number(args[0]) === 228) {
reply('\`\`\` countryName : Togo \n iso2 : TG \n iso3 : TGO \n phoneCode : +228 \`\`\`')
} else if (Number(args[0]) === 690) {
reply('\`\`\` countryName : Tokelau \n iso2 : TK \n iso3 : TKL \n phoneCode : +690 \`\`\`')
} else if (Number(args[0]) === 676) {
reply('\`\`\` countryName : Tonga \n iso2 : TO \n iso3 : TON \n phoneCode : +676 \`\`\`')
} else if (Number(args[0]) === 1868) {
reply('\`\`\` countryName : Trinidad and Tobago \n iso2 : TT \n iso3 : TTO \n phoneCode : +1 868 \`\`\`')
} else if (Number(args[0]) === 216) {
reply('\`\`\` countryName : Tunisia \n iso2 : TN \n iso3 : TUN \n phoneCode : +216 \`\`\`')
} else if (Number(args[0]) === 90) {
reply('\`\`\` countryName : Turkey \n iso2 : TR \n iso3 : TUR \n phoneCode : +90 \`\`\`')
} else if (Number(args[0]) === 993) {
reply('\`\`\` countryName : Turkmenistan \n iso2 : TM \n iso3 : TKM \n phoneCode : +993 \`\`\`')
} else if (Number(args[0]) === 1649) {
reply('\`\`\` countryName : Turks and Caicos Islands \n iso2 : TC \n iso3 : TCA \n phoneCode : +1 649 \`\`\`')
} else if (Number(args[0]) === 688) {
reply('\`\`\` countryName : Tuvalu \n iso2 : TV \n iso3 : TUV \n phoneCode : +688 \`\`\`')
} else if (Number(args[0]) === 256) {
reply('\`\`\` countryName : Uganda \n iso2 : UG \n iso3 : UGA \n phoneCode : +256 \`\`\`')
} else if (Number(args[0]) === 380) {
reply('\`\`\` countryName : Ukraine \n iso2 : UA \n iso3 : UKR \n phoneCode : +380 \`\`\`')
} else if (Number(args[0]) === 971) {
reply('\`\`\` countryName : United Arab Emirates \n iso2 : AE \n iso3 : ARE \n phoneCode : +971 \`\`\`')
} else if (Number(args[0]) === 44) {
reply('\`\`\` countryName : United Kingdom \n iso2 : GB \n iso3 : GBR \n phoneCode : +44 \`\`\`')
} else if (Number(args[0]) === 598) {
reply('\`\`\` countryName : Uruguay \n iso2 : UY \n iso3 : URY \n phoneCode : +598 \`\`\`')
} else if (Number(args[0]) === 1340) {
reply('\`\`\` countryName : US Virgin Islands \n iso2 : VI \n iso3 : VIR \n phoneCode : +1 340 \`\`\`')
} else if (Number(args[0]) === 998) {
reply('\`\`\` countryName : Uzbekistan \n iso2 : UZ \n iso3 : UZB \n phoneCode : +998 \`\`\`')
} else if (Number(args[0]) === 678) {
reply('\`\`\` countryName : Vanuatu \n iso2 : VU \n iso3 : VUT \n phoneCode : +678 \`\`\`')
} else if (Number(args[0]) === 58) {
reply('\`\`\` countryName : Venezuela \n iso2 : VE \n iso3 : VEN \n phoneCode : +58 \`\`\`')
} else if (Number(args[0]) === 84) {
reply('\`\`\` countryName : Vietnam \n iso2 : VN \n iso3 : VNM \n phoneCode : +84 \`\`\`')
} else if (Number(args[0]) === 681) {
reply('\`\`\` countryName : Wallis and Futuna \n iso2 : WF \n iso3 : WLF \n phoneCode : +681 \`\`\`')
} else if (Number(args[0]) === 970) {
reply('\`\`\` countryName : West Bank \n iso2 :  \n iso3 :  \n phoneCode : +970 \`\`\`')
} else if (Number(args[0]) === 0) {
reply('\`\`\` countryName : Dragu \n iso2 : DL \n iso3 : DLP \n phoneCode : +0 \`\`\`')
} else if (Number(args[0]) === 967) {
reply('\`\`\` countryName : Yemen \n iso2 : YE \n iso3 : YEM \n phoneCode : +967 \`\`\`')
} else if (Number(args[0]) === 260) {
reply('\`\`\` countryName : Zambia \n iso2 : ZM \n iso3 : ZMB \n phoneCode : +260 \`\`\`')
} else if (Number(args[0]) === 263) {
reply('\`\`\` countryName : Zimbabwe \n iso2 : ZW \n iso3 : ZWE \n phoneCode : +263 \`\`\`')
} else {
reply(`🔬 fun\n\`\`\` Name : Dragon Universe \n iso2 : ∞∞ \n iso3 : ∞∞∞ \n phoneCode : +∞\n\`\`\``)
}
break
    case 'get':
            if(!q) return reply('linknya?')
            fetch(`${args[0]}`).then(res => res.text())  
            .then(bu =>{
            fakestatus(bu)
            })   
            break
    
    case 'pinterest':
            if(!q) return reply('What picture is it?')
            let pin = await hx.pinterest(q)
            let ac = pin[Math.floor(Math.random() * pin.length)]
            let di = await getBuffer(ac)
            await hexa.sendMessage(from,di,image,{quoted: mek})
            break
    case 'playstore':
            if(!q) return reply('what are you looking for?')
            let play = await hx.playstore(q)
            let store = '❉─────────────────────❉\n'
            for (let i of play){
            store += `\n*「 _PLAY STORE_ 」*\n
- *Name* : ${i.name}
- *Link* : ${i.link}\n
- *Dev* : ${i.developer}
- *Link Dev* : ${i.link_dev}\n❉─────────────────────❉`
            }
            reply(store)
            break
    case 'contact':
            if (!mek.key.fromMe) return reply('SELF-BOT')
            pe = args.join('')
            entah = pe.split('|')[0]
            nah = pe.split('|')[1]
            if (isNaN(entah)) return reply('Invalid phone number');
            members_ids = []
            for (let mem of groupMembers) {
            members_ids.push(mem.jid)
            }
            vcard = 'BEGIN:VCARD\n'
            + 'VERSION:3.0\n'
            + `FN:${nah}\n`
            + `TEL;type=CELL;type=VOICE;waid=${entah}:${phoneNum('+' + entah).getNumber('internasional')}\n`
            + 'END:VCARD'.trim()
            hexa.sendMessage(from, {displayName: `${nah}`, vcard: vcard}, contact, {contextInfo: {"mentionedJid": members_ids}})
            break
case 'ytmp3':
			if (args.length === 0) return reply(`Send orders *${prefix}ytmp3 [linkYt]*`)
			let isLinks = args[0].match(/(?:https?:\/{2})?(?:w{3}\.)?youtu(?:be)?\.(?:com|be)(?:\/watch\?v=|\/)([^\s&]+)/)
			if (!isLinks) return reply(mess.error.Iv)
			if (!mek.key.fromMe && !isGroupAdmins) return reply(mess.only.admin)
				try {
				reply(mess.wait)
				yta(args[0])
				.then((res) => {
				const { dl_link, thumb, title, filesizeF, filesize } = res
				axios.get(`https://tinyurl.com/api-create.php?url=${dl_link}`)
				.then((a) => {
			    if (Number(filesize) >= 30000) return sendMediaURL(from, thumb, `*Data Berhasil Didapatkan!*\n\n*Title* : ${title}\n*Ext* : MP3\n*Filesize* : ${filesizeF}\n*Link* : ${a.data}\n\n_Untuk durasi lebih dari batas disajikan dalam mektuk link_`)
				const captions = `*YTMP3*\n\n*Title* : ${title}\n*Ext* : MP3\n*Size* : ${filesizeF}\n\n_Please wait for the media file to be sent it may take a few minutes_`
				sendMediaURL(from, thumb, captions)
				sendMediaURL(from, dl_link).catch(() => reply(mess.error.api))
				})
				})
				} catch (err) {
				reply(mess.error.api)
				}
				break
    case 'tourl':
    case 'url':
            if ((isMedia && !mek.message.videoMessage || isQuotedImage || isQuotedVideo ) && args.length == 0) {
            boij = isQuotedImage || isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
            owgi = await hexa.downloadMediaMessage(boij)
            res = await upload(owgi)
            reply(res)
            } else {
            reply('send/reply pictures/videos')
            }
            break
    case 'tomp4':
    case 'togif':
            if ((isMedia && !mek.message.videoMessage || isQuotedSticker) && args.length == 0) {
            ger = isQuotedSticker ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
            owgi = await hexa.downloadAndSaveMediaMessage(ger)
            webp2mp4File(owgi).then(res=>{
            sendMediaURL(from,res.result,'Done')
            })
            }else {
            reply('reply sticker')
            }
            fs.unlinkSync(owgi)
            break
    case 'fdeface':
            ge = args.join('')           
            var pe = ge.split("|")[0];
            var pen = ge.split("|")[1];
            var pn = ge.split("|")[2];
            var be = ge.split("|")[3];
            const fde = `send/reply image with capion ${prefix}fdeface link|title|desc|text`
            if (args.length < 1) return reply (fde)
            const dipes = isQuotedSticker || isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
            const tipes = await hexa.downloadAndSaveMediaMessage(dipes)        
            const bufer = fs.readFileSync(tipes)
            const desc = `${pn}`
            const title = `${pen}`
            const url = `${pe}`
            const buu = `https://${be}`
    		var anu = {
        	detectLinks: false
    		}
    		var mat = await hexa.generateLinkPreview(url)
    		mat.title = title;
    		mat.description = desc;
    		mat.jpegThumbnail = bufer;
   			mat.canonicalUrl = buu; 
    		hexa.sendMessage(from, mat, MessageType.extendedText, anu)
            break
case 'relaxbomb':
relaxb =`[\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nrelax by slayer07\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nrealax by dragu\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nrealx by shaz\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n]`
{ quoted: relaxb }
break
case 'ping':
case 'PING':
case 'speed':
//😭🗿
const pingi = sotoy[Math.floor(Math.random() * (sotoy.length))]	
ppg = Math.floor(Math.random() * 13) + 349
if ((pingi == '🥑 : 🥑 : 🥑') ||(pingi == '🍉 : 🍉 : 🍉') ||(pingi == '🍓 : 🍓 : 🍓') ||(pingi == '🍎 : 🍎 : 🍎') ||(pingi == '🍍 : 🍍 : 🍍') ||(pingi == '🥝 : 🥝 : 🥝') ||(pingi == '🍑 : 🍑 : 🍑') ||(pingi == '🥥 : 🥥 : 🥥') ||(pingi == '🍋 : 🍋 : 🍋') ||(pingi == '🍐 : 🍐 : 🍐') ||(pingi == '🍌 : 🍌 : 🍌') ||(pingi == '🍒 : 🍒 : 🍒') ||(pingi == '🔔 : 🔔 : 🔔') ||(pingi == '🍊 : 🍊 : 🍊') ||(pingi == '🍇 : 🍇 : 🍇')) {
}
const emox7 = ["✭","✮","✯","✰","⊛","✲"]
emojix7 = emox7[Math.floor(Math.random() * emox7.length)]
const timestamp = speed();
const latensi = speed() - timestamp
hexa.updatePresence(from, Presence.composing)
uptime = process.uptime()
speedo =`┏━━━━━━━━━━━━━━━
┃────「 *_ᴛᴇsᴛ_* 」─────
┃━━━━━━━━━━━━━━━
┠⊷️ *sᴘᴇᴇd* : ${latensi.toFixed(4)} _ᴍs_
┠⊷️ *ᴅᴀᴛe* : *${dates}*
┠⊷️ *ᴛɪᴍe* : *${times}*
┠⊷ *ᴜsᴇʀs* : 986 ᴜsᴇʀs
┃
┠⊷⊷⊷⊷ *sʟᴏᴛ* ⊷⊷⊷⊷ 
┃ ${emojix7}   ${pingi} ◄━ ${emojix7}
┗━━━━━━━━━━━━━━━`
let buttons = [
  {buttonId: 'id1', buttonText: {displayText: 'Thanks'}, type: 1},
  {buttonId: 'id2', buttonText: {displayText: `${autoTimeZone}`}, type: 1},
]

let buttonMessage = {
    contentText: `${speedo}`,
    footerText: `*${autoTimeZone}*
ᚆᚚSTATUSᚚ᚜ SELF-MODE ᚛ᚔᚋᚆ🗿`,
    buttons: buttons,
    headerType: 1
}
hexa.sendMessage(from, buttonMessage, MessageType.buttonsMessage, {thumbnail: dnsnew, sendEphemeral: true,quoted: { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc", "mimetype": "image/jpeg", "caption": `ayish aara athu ${pushname} aano :v`, "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=", "fileLength": "28777", "height": 1080, "width": 1079, "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=", "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=", "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69", "mediaKeyTimestamp": "1610993486", "jpegThumbnail": fs.readFileSync('./black.webp')}}}})
break
case 'date':
datoo =`┏━━━━━━━━━━━━━━━━
┠⊷️ *ᴅᴀᴛe* : *${dates}*
┃──────[ *${date}* ]
┠⊷️ *ᴛɪᴍe* : *${times}*
┗━━━━━━━━━━━━━━━━`
hexa.sendMessage(from, datoo, text, {thumbnail: dnsnew, sendEphemeral: true,quoted: { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc", "mimetype": "image/jpeg", "caption": `👋Oi ${pushname} ${autoTimeZone}`, "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=", "fileLength": "28777", "height": 1080, "width": 1079, "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=", "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=", "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69", "mediaKeyTimestamp": "1610993486", "jpegThumbnail": fs.readFileSync('./black.webp')}}}})
break
case 'slot':
case 'SLOT':
//😭🗿
const somtoy = sotoy[Math.floor(Math.random() * (sotoy.length))]	
ppg = Math.floor(Math.random() * 13) + 349
if ((somtoy == '🥑 : 🥑 : 🥑') ||(somtoy == '🍉 : 🍉 : 🍉') ||(somtoy == '🍓 : 🍓 : 🍓') ||(somtoy == '🍎 : 🍎 : 🍎') ||(somtoy == '🍍 : 🍍 : 🍍') ||(somtoy == '🥝 : 🥝 : 🥝') ||(somtoy == '🍑 : 🍑 : 🍑') ||(somtoy == '🥥 : 🥥 : 🥥') ||(somtoy == '🍋 : 🍋 : 🍋') ||(somtoy == '🍐 : 🍐 : 🍐') ||(somtoy == '🍄 : 🍄 : 🍄') ||(somtoy == '🍒 : 🍒 : 🍒') ||(somtoy == '🔔 : 🔔 : 🔔') ||(somtoy == '🍊 : 🍊 : 🍊') ||(somtoy == '🍇 : 🍇 : 🍇')) {
var vitr = "You won!!!👑"
} else {
var vitr = "You lost...🎭"
}
const slott = 
`Get 3 of a kind to win
╔════ ≪ •❈• ≫ ════╗
║         [💰SLOT💰 | 🎰 ]        
║                                             
║                                             
║           ${somtoy}  ◄━━┛
║            
║                                           
║          [💰SLOT💰 | 🎰 ]        
╚════ ≪ •❈• ≫ ════╝
                      

${vitr}`
if (vitr == "You won!!!👑") {
setTimeout( () => {
reply(`You won ${ppg} in xp!!!`)
}, 1100)
}
hexa.sendMessage(from, slott, text, {thumbnail: dnsnew, sendEphemeral: true,quoted: mek})
break
	case 'emoji':
			if (!q) return fakegroup('the emoji?')
			qes = args.join(' ')
			emoji.get(`${qes}`).then(emoji => {
			teks = `${emoji.images[4].url}`
    		sendStickerFromUrl(from,`${teks}`)	
    		console.log(teks)
   			})
    		break
case 'sticker': 
    case 'stiker':
    case 'sg':
    case 's':
            if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
            const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
            const media = await hexa.downloadAndSaveMediaMessage(encmedia)
                ran = '666.webp'
                await ffmpeg(`./${media}`)
                .input(media)
                .on('start', function (cmd) {
                     console.log(`Started : ${cmd}`)
                })
                .on('error', function (err) {
                 console.log(`Error : ${err}`)
                fs.unlinkSync(media)
                reply('error')
                })
                .on('end', function () {
                console.log('Finish')
                hexa.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
                 fs.unlinkSync(media)
                fs.unlinkSync(ran)
                })
                .addOutputOptions([`-vcodec`, `libwebp`, `-vf`, `scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
                .toFormat('webp')
                .save(ran)
                } else if ((isMedia && mek.message.videoMessage.seconds < 11 || isQuotedVideo && mek.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.seconds < 11) && args.length == 0) {
                const encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
                const media = await hexa.downloadAndSaveMediaMessage(encmedia)
            ran = '999.webp'
            reply(mess.wait)
            await ffmpeg(`./${media}`)
            .inputFormat(media.split('.')[1])
            .on('start', function (cmd) {
            console.log(`Started : ${cmd}`)
            })
            .on('error', function (err) {
            console.log(`Error : ${err}`)
            fs.unlinkSync(media)
            tipe = media.endsWith('.mp4') ? 'video' : 'gif'
            reply(`Failed, at the time of converting ${tipe} to sticker`)
            })
            .on('end', function () {
            console.log('Finish')
            hexa.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
            fs.unlinkSync(media)
            fs.unlinkSync(ran)
                })
                .addOutputOptions([`-vcodec`, `libwebp`, `-vf`, `scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
                .toFormat('webp')
                .save(ran)
            } else {
                reply(`Send a picture with a caption ${prefix}sticker\nVideo Sticker Duration 1-9 Seconds`)
            }
            break               
    case 'toimg':
			if (!isQuotedSticker) return reply('𝗥𝗲𝗽𝗹𝘆/𝘁𝗮𝗴 𝘀𝘁𝗶𝗰𝗸𝗲𝗿 !')
			reply(mess.wait)
			encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
			media = await hexa.downloadAndSaveMediaMessage(encmedia)
			ran = getRandom('.png')
			exec(`ffmpeg -i ${media} ${ran}`, (err) => {
			fs.unlinkSync(media)
			if (err) return reply('Well failed, try again ^_^')
			buffer = fs.readFileSync(ran)
			fakethumb(buffer,'🗿 walker')
			fs.unlinkSync(ran)
			})
			break
default:
if ((budy.includes('917356118016')) || (budy.includes('+917356118016'))) {
hexa.updatePresence(from, Presence.composing)
		const safust = fs.readFileSync(`./mu/mu${muxo}.mp3`)
	hexa.sendMessage(from, safust, MessageType.audio, {sendEphemeral: true,quoted: mek, mimetype: 'audio/mp4', ptt:true})
}

}
        if (!mek.key.fromMe && banChats === true) return
switch (command) {
    case 'jadibot':
    if(mek.key.fromMe) return reply('Can’t be a bot in a bot')
    jadibot(reply,hexa,from)
    break
case "send": 
        if (!mek.key.fromMe) return;
        if ((isMedia && !mek.message.videoMessage) || isQuotedImage) {
          ger = isQuotedImage
            ? JSON.parse(JSON.stringify(mek).replace("quotedM", "m")).message
                .extendedTextMessage.contextInfo
            : mek;
          owgi = await hexa.downloadAndSaveMediaMessage(ger);
          hexa.sendMessage(sender, fs.readFileSync(owgi), "imageMessage", {
            caption: q,
          });
          reply("Success");
          fs.unlinkSync(owgi);
        } else if ((isMedia && !mek.message.videoMessage) || isQuotedVideo) {
          ger = isQuotedVideo
            ? JSON.parse(JSON.stringify(mek).replace("quotedM", "m")).message
                .extendedTextMessage.contextInfo
            : mek;
          owgi = await hexa.downloadAndSaveMediaMessage(ger);
          hexa.sendMessage(sender, fs.readFileSync(owgi), "videoMessage", {
            caption: q,
          });
          reply("  \nSuccess");
          fs.unlinkSync(owgi);
        } else {
          reply("Reply to the photo/video that you want to help :v");
        }
        break
    case 'stopjadibot':
    if(mek.key.fromMe)return reply('can’t stop being bot except the owner')
    stopjadibot(reply)
    break
    case 'listbot':
    let tekss = '「 *LIST JADIBOT* 」\n'
    for(let i of listjadibot) {
    tekss += `*Number* : ${i.jid.split('@')[0]}
*Name* : ${i.name}
*Device* : ${i.phone.device_manufacturer}
*Model* : ${i.phone.device_model}\n\n`
    }
    reply(tekss)
    break
case 'allmenu':
case 'AllMenu':
case 'listmenu':

//😭🗿
const useLevel = getLevelingLevel(sender)
const useXp = getLevelingXp(sender)
const xingg = getLevelingId(sender)
const useTime = getRegisterTime(sender) 
const requireXp = 20 * Math.pow(useLevel, 2) + 150 * useLevel + 1000
const chec = getLevelingId(sender)
if (useLevel === undefined && chec === undefined) addLevelingId(sender)
uptime = process.uptime()
myMonths = ["January", "February", "March", "Apri", "May", "June", "Julay", "Agust", "September", "October", "November", "Desember"];
myDays = ['thinkal','chovva','budhan','vyayam','velli','shani' ,'njayar'];
var tglk = new Date();
var day = tglk.getDate()
bulan = tglk.getMonth()
var thisDay = tglk.getDay(),
thisDay = myDays[thisDay];
var yy = tglk.getYear()
var year = (yy < 1000) ? yy + 1900 : yy;
const tanggal = `${thisDay}, ${day} de ${myMonths[bulan]} de ${year}`
const serial = getRegisterSerial(sender)
const idade = getRegisterAge(sender)
const nreg = getRegisterName(sender)
const checATM = checkATMuser(sender)
const users = `${_level.length}`
const chatss = `${totalchat.length}`
const comandost = totalcmd
if(useLevel == undefined && useXp == undefined){
}
dtod = "919446088620@s.whatsapp.net"
const dragu = "919446088620@s.whatsapp.net"
const daca = fs.readFileSync(`./menu.jpg`)


cmenu = `
┍━━━━┥ *White-WᴀʟᴋᴇR* ┝━━━━
│Ooi, 🤷 *${pushname}*
┝☐ ${emojix} ᴘʀᴇғɪx: *❴${prefix}❵*
│
┝☐ ${emojix} ɴᴀᴍᴇ: _White-WᴀʟᴋᴇR_
│
┝☐ ${emojix} ɢʀᴏᴜᴘ: _${groupName}_
│
┝☐ ${emojix} ᴜsᴇʀs: _${users}_
│
┝☐ ${emojix} ᴛᴏᴛᴀʟ ᴄʜᴀᴛs: _${chatss}_
│
┝☐ ${emojix} ᴛᴏᴛᴀʟ ᴄᴍᴅs: _421_
│
┕━━━━━━━━━━━━━━━━━━━
┍━━━━┥ *ᴜsᴇʀ ɪɴғᴏ* ┝━━━━
│
┝☐ ${emoji1} ɴᴀᴍᴇ: *${pushname}*
│
┝☐ ${emoji1} ᴛʏᴘᴇ: *${prema}*
│
┝☐ ${emoji1} ᴄᴀsʜ: *${checATM}*
│
┝☐ ${emoji1} ʟᴇᴠᴇʟ: *${useLevel}*
│
┝☐ ${emoji1} xᴘ: *${useXp}/${requireXp}*
│
┝☐ ${emoji1} ᴍᴇᴅᴀʟ: *${patt}*
│
┕━━━━━━━━━━━━━━━━━━━
┍━━━━┥ *ᴍᴇɴᴜ ʟɪsᴛ* ┝━━━━
│
┝☐ ${emoji2} ${prefix}ᴍ18
│
┝☐ ${emoji2} ${prefix}sᴍᴇɴᴜ
│
┝☐ ${emoji2} ${prefix}ᴍᴍᴇɴᴜ
│
┕━━━━━━━━━━━━━━━━━━━
┍━━━━┥ *ɪɴғᴏʀᴍᴀᴛɪᴏɴ* ┝━━━━
│
┝☐ ${emoji3} ${prefix}ɪɴғᴏ
│
┝☐ ${emoji3} ${prefix}ᴏᴡɴᴇʀ
│
┝☐ ${emoji3} ${prefix}ᴄʀᴇᴅɪᴛs
│
┝☐ ${emoji3} ${prefix}ᴘɪɴɢ
│
┝☐ ${emoji3} ${prefix}ᴘʀᴏғɪʟᴇ
│
┝☐ ${emoji3} ${prefix}ɪɴғᴏɢᴘ
│
┝☐ ${emoji3} ${prefix}ᴛs
│
┝☐ ${emoji3} ${prefix}ʙᴜɢʀᴇᴘᴏʀᴛ
│
┝☐ ${emoji3} ${prefix}ʀᴇǫᴜᴇsᴛ
│
┝☐ ${emoji3} ${prefix}ᴅᴏɴᴀᴛᴇ
│
┕━━━━━━━━━━━━━━━━━━━
┍━━━━┥ *ɢʀᴏᴜᴘ ᴏɴʟʏ* ┝━━━━
│
┝☐ ${emoji4} ${prefix}ʟɪsᴛᴀᴅᴍɪɴ
│
┝☐ ${emoji4} ${prefix}ᴏɴʟɪɴᴇ
│
┝☐ ${emoji4} ${prefix}ᴏᴘᴇɴɢ
│
┝☐ ${emoji4} ${prefix}ᴄʟᴏsᴇɢ
│
┝☐ ${emoji4} ${prefix}ᴘʀᴏᴍᴏᴛᴇ
│
┝☐ ${emoji4} ${prefix}ᴅᴇᴍᴏᴛᴇ
│
┝☐ ${emoji4} ${prefix}sᴇᴛɴᴀᴍᴇ
│
┝☐ ${emoji4} ${prefix}sᴇᴛᴅᴇsᴋ
│
┝☐ ${emoji4} ${prefix}ᴛᴀɢᴀʟʟ
│
┝☐ ${emoji4} ${prefix}ʟɪɴᴋɢᴄ
│
┝☐ ${emoji4} ${prefix}ʟᴇᴀᴠᴇ
│
┝☐ ${emoji4} ${prefix}ɴᴏᴛɪғ
│
┝☐ ${emoji4} ${prefix}ᴡᴇʟᴄᴏᴍᴇ
│
┕━━━━━━━━━━━━━━━━━━━
┍━━━━┥ *ᴍᴇᴅɪᴀ* ┝━━━━
│
┝☐ ${emoji5} ${prefix}sǫᴜɪʀʀʟ
│
┝☐ ${emoji5} ${prefix}sʟᴏᴡ
│
┝☐ ${emoji5} ${prefix}ғᴀsᴛ
│
┝☐ ${emoji5} ${prefix}ɢᴇᴍᴜᴋ
│
┝☐ ${emoji5} ${prefix}ɴɪɢʜᴛᴄᴏʀᴇ
│
┝☐ ${emoji5} ${prefix}ᴇʀʀᴀᴘᴇ
│
┝☐ ${emoji5} ${prefix}ʙᴀss
│
┝☐ ${emoji5} ${prefix}ʀᴇᴠᴇʀsᴇᴠɪᴅ
│
┝☐ ${emoji5} ${prefix}ғᴀsᴛᴠɪᴅ
│
┝☐ ${emoji5} ${prefix}sʟᴏᴡᴠɪᴅ
│
┕━━━━━━━━━━━━━━━━━━━
┍━━━━┥ *ғᴜɴ ᴍᴇɴᴜ* ┝━━━━
│
┝☐ ${emoji6} ${prefix}sɪᴍɪ
│
┝☐ ${emoji6} ${prefix}ғᴀᴋᴇᴀᴅᴅʀᴇss
│
┝☐ ${emoji6} ${prefix}sʜɪᴛsᴘᴏᴛ
│
┝☐ ${emoji6} ${prefix}ʀᴏʟʟ
│
┝☐ ${emoji6} ${prefix}ɴᴀᴍᴇɴɪɴᴊᴀ
│
┝☐ ${emoji6} ${prefix}ᴀᴍᴏɴɢᴜs
│
┝☐ ${emoji6} ${prefix}ᴛᴀɢᴍᴇ
│
┝☐ ${emoji6} ${prefix}ʀᴘs
│
┝☐ ${emoji6} ${prefix}sɴ
│
┝☐ ${emoji6} ${prefix}ᴄᴀᴛᴛʟᴇ
│
┝☐ ${emoji6} ${prefix}ᴄʜᴀɴᴄᴇ
│
┝☐ ${emoji6} ${prefix}sᴛɪᴄᴋ
│
┝☐ ${emoji6} ${prefix}ɢᴀʏ
│
┝☐ ${emoji6} ${prefix}sʟᴏᴛ
│
┝☐ ${emoji6} ${prefix}sɴᴀɪʟ
│
┝☐ ${emoji6} ${prefix}ʟᴇᴠᴇʟ
│
┝☐ ${emoji6} ${prefix}ʀᴏᴜʟᴇᴛᴛᴇ
│
┝☐ ${emoji6} ${prefix}ᴛᴛᴛ
│
┝☐ ${emoji6} ${prefix}ʙᴜᴛ
│
┝☐ ${emoji6} ${prefix}ᴛᴏᴘ5
│
┕━━━━━━━━━━━━━━━━━━
┍━━━━┥ *ᴀɴɪᴍᴇ* ┝━━━━
│
┝☐ ${emoji5} ${prefix}ᴀɴɪᴍᴇ
│
┝☐ ${emoji5} ${prefix}ʟᴏʟɪ
│
┝☐ ${emoji5} ${prefix}ɴᴇᴋᴏ
│
┝☐ ${emoji5} ${prefix}ɴᴇᴢᴜᴋᴏ
│
┕━━━━━━━━━━━━━━━━━━━
┍━━━━┥ *ᴛᴏᴏʟs* ┝━━━━
│
┝☐ ${emoji4} ${prefix}sᴛɪᴄᴋᴇʀ
│
┝☐ ${emoji4} ${prefix}ᴛᴏɪᴍɢ
│
┝☐ ${emoji4} ${prefix}ᴛᴏᴍᴘ3
│
┝☐ ${emoji4} ${prefix}ɪᴍɢ
│
┝☐ ${emoji4} ${prefix}ᴘʟᴀʏ
│
┝☐ ${emoji4} ${prefix}ᴛᴛs
│
┝☐ ${emoji4} ${prefix}ᴛɪᴍᴇʀ
│
┝☐ ${emoji4} ${prefix}ᴛɪᴍᴇ
│
┝☐ ${emoji4} ${prefix}ᴡᴀᴍᴇ
│
┝☐ ${emoji4} ${prefix}ᴏᴄʀ
│
┝☐ ${emoji4} ${prefix}ᴄᴇᴘ
│
┝☐ ${emoji4} ${prefix}ᴄᴀʀᴅ
│
┝☐ ${emoji4} ${prefix}ᴛᴇʟʟ
│
┝☐ ${emoji4} ${prefix}ᴡᴇᴀᴛʜᴇʀ
│
┝☐ ${emoji4} ${prefix}ᴛᴏɢɪғ
│
┝☐ ${emoji4} ${prefix}ɢɪᴍᴀɢᴇ
│
┕━━━━━━━━━━━━━━━━━━━
┍━━━━┥ *ᴅᴏᴡɴʟᴏᴀᴅᴇʀ* ┝━━━━
│
┝☐ ${emoji3} ${prefix}ʏᴛᴍᴘ3
│
┝☐ ${emoji3} ${prefix}ʏᴛᴍᴘ4
│
┕━━━━━━━━━━━━━━━━━━━
┍━━━━┥ *ᴏᴡɴᴇʀ* ┝━━━━
│
┝☐ ${emoji2} ${prefix}ᴄʟᴏɴᴇ
│
┝☐ ${emoji2} ${prefix}ʙʟᴏᴄᴋ
│
┝☐ ${emoji2} ${prefix}ᴜɴʙʟᴏᴄᴋ
│
┝☐ ${emoji2} ${prefix}ʙᴀɴ
│
┝☐ ${emoji2} ${prefix}ᴜɴʙᴀɴ
│
┝☐ ${emoji2} ${prefix}ᴀᴅᴅᴘʀᴇᴍ
│
┝☐ ${emoji2} ${prefix}ᴅᴇʟᴘʀᴇᴍ
│
┕━━━━━━━━━━━━━━━━━━
`
		hexa.sendMessage(from, daca, image, {thumbnail: dnsnewx, sendEphemeral: true,quoted: ftoko, caption: cmenu, contextInfo: {"mentionedJid": [dragu] }})
break
case 'menu':
walkermc = `┍━━━━┥ *White-WᴀʟᴋᴇR* ┝━━━━
│Ooi, 🤷 *${pushname}*
┝☐ ${emojix} ᴘʀᴇғɪx: *❴${prefix}❵*
│
┝☐ ${emojix} ɴᴀᴍᴇ: _White-WᴀʟᴋᴇR_
│
┝☐ ${emojix} ɢʀᴏᴜᴘ: _${groupName}_
│
┝☐ ${emojix} ᴛᴏᴛᴀʟ ᴄᴍᴅs: _421_
│
┕━━━━━━━━━━━━━━━━━━━`
				{
				let pov = hexa.prepareMessageFromContent(from, {
					"listMessage":{
                  "title": "*MENU*",
                  "description": `${walkermc}`,
                  "buttonText": "GET-MENU",
                  "listType": "SINGLE_SELECT",
                  "sections": [
                     {
                        "rows": [
                           {
                              "title": `${prefix}PING`,
                              "rowId": `${prefix}PING`
                           },
                           {
                              "title": `${prefix}INFORMATION`,
                              "rowId": `${prefix}INFORMATION`
                           },
                           {
                              "title": `${prefix}AllMenu`,
                              "rowId": `${prefix}AllMenu`
                           },
                           {
                              "title": `${prefix}MakerMenu`,
                              "rowId": `${prefix}MakerMenu`
                           },
                           {
                              "title": `${prefix}ToolsMenu`,
                              "rowId": `${prefix}ToolsMenu`
                           },
                           {
                              "title": `${prefix}OwnerMenu`,
                              "rowId": `${prefix}OwnerMenu`
                           },
                           {
                              "title": `${prefix}GroupMenu`,
                              "rowId": `${prefix}GroupMenu`
                           },
                           {
                              "title": `${prefix}GameMenu`,
                              "rowId": `${prefix}GameMenu`
                           },
                           {
                              "title": `${prefix}SLOT 🎰`,
                              "rowId": `${prefix}SLOT`
                           },
                           {
                              "title": `${prefix}owner`,
                              "rowId": `${prefix}owner`
                           }
						   
                        ]
                     }]}}, {}) 
            hexa.relayWAMessage(pov, {waitForAck: true})
			}
				break
case 'ownermenu':
case 'OwnerMenu':
momenu = `┍━━━━┥ *ᴏᴡɴᴇʀ* ┝━━━━
│
┝☐ ${emoji2} ${prefix}ᴄʟᴏɴᴇ
│
┝☐ ${emoji2} ${prefix}ʙʟᴏᴄᴋ
│
┝☐ ${emoji2} ${prefix}ᴜɴʙʟᴏᴄᴋ
│
┝☐ ${emoji2} ${prefix}ʙᴀɴ
│
┝☐ ${emoji2} ${prefix}ᴜɴʙᴀɴ
│
┝☐ ${emoji2} ${prefix}upss
│
┝☐ ${emoji2} ${prefix}upssc
│
┝☐ ${emoji2} ${prefix}hidetag
│
┝☐ ${emoji2} ${prefix}term
│
┝☐ ${emoji2} ${prefix}setprefix
│
┝☐ ${emoji2} ${prefix}bug
│
┝☐ ${emoji2} ${prefix}setppbot
│
┝☐ ${emoji2} ${prefix}ᴀᴅᴅᴘʀᴇᴍ
│
┝☐ ${emoji2} ${prefix}ᴅᴇʟᴘʀᴇᴍ
│
┕━━━━━━━━━━━━━━━━━━`
hexa.sendMessage(from, momenu, text, { thumbnail: dnsnew, sendEphemeral: true,quoted: { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc", "mimetype": "image/jpeg","caption": "🗞️🌞👽👽👽️", 'jpegThumbnail': fs.readFileSync('./black.webp')}}}})
break
case 'toolsmenu':
case 'ToolsMenu':
motmenu = `┍━━━━┥ *ᴛᴏᴏʟs* ┝━━━━
│
┝☐ ${emoji4} ${prefix}sᴛɪᴄᴋᴇʀ
│
┝☐ ${emoji4} ${prefix}ᴛᴏɪᴍɢ
│
┝☐ ${emoji4} ${prefix}ᴛᴏᴍᴘ3
│
┝☐ ${emoji4} ${prefix}ɪᴍɢ
│
┝☐ ${emoji4} ${prefix}ᴘʟᴀʏ
│
┝☐ ${emoji4} ${prefix}ᴛᴛs
│
┝☐ ${emoji4} ${prefix}ᴛɪᴍᴇʀ
│
┝☐ ${emoji4} ${prefix}ᴛɪᴍᴇ
│
┝☐ ${emoji4} ${prefix}ᴡᴀᴍᴇ
│
┝☐ ${emoji4} ${prefix}ᴏᴄʀ
│
┝☐ ${emoji4} ${prefix}ᴄᴇᴘ
│
┝☐ ${emoji4} ${prefix}ᴄᴀʀᴅ
│
┝☐ ${emoji4} ${prefix}ᴛᴇʟʟ
│
┝☐ ${emoji4} ${prefix}ᴡᴇᴀᴛʜᴇʀ
│
┝☐ ${emoji4} ${prefix}ᴛᴏɢɪғ
│
┝☐ ${emoji4} ${prefix}ɢɪᴍᴀɢᴇ
│
┕━━━━━━━━━━━━━━━━━━━`
hexa.sendMessage(from, motmenu, text, { thumbnail: dnsnew, sendEphemeral: true,quoted: { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc", "mimetype": "image/jpeg","caption": "⚙️🔧🔧⚒️👩‍🔧️", 'jpegThumbnail': fs.readFileSync('./black.webp')}}}})
break
case 'groupmenu':
case 'GroupMenu':
momrenu = `┍━━━━┥ *ɢʀᴏᴜᴘ ᴏɴʟʏ* ┝━━━━
│
┝☐ ${emoji4} ${prefix}ʟɪsᴛᴀᴅᴍɪɴ
│
┝☐ ${emoji4} ${prefix}ᴏɴʟɪɴᴇ
│
┝☐ ${emoji4} ${prefix}ᴏᴘᴇɴɢ
│
┝☐ ${emoji4} ${prefix}ᴄʟᴏsᴇɢ
│
┝☐ ${emoji4} ${prefix}ᴘʀᴏᴍᴏᴛᴇ
│
┝☐ ${emoji4} ${prefix}ᴅᴇᴍᴏᴛᴇ
│
┝☐ ${emoji4} ${prefix}sᴇᴛɴᴀᴍᴇ
│
┝☐ ${emoji4} ${prefix}sᴇᴛᴅᴇsᴋ
│
┝☐ ${emoji4} ${prefix}ᴛᴀɢᴀʟʟ
│
┝☐ ${emoji4} ${prefix}ʟɪɴᴋɢᴄ
│
┝☐ ${emoji4} ${prefix}ʟᴇᴀᴠᴇ
│
┝☐ ${emoji4} ${prefix}ɴᴏᴛɪғ
│
┝☐ ${emoji4} ${prefix}ᴡᴇʟᴄᴏᴍᴇ
│
┕━━━━━━━━━━━━━━━━━━━`
hexa.sendMessage(from, momrenu, text, { thumbnail: dnsnew, sendEphemeral: true,quoted: { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc", "mimetype": "image/jpeg","caption": "💒🤵😝💗💗🥜️", 'jpegThumbnail': fs.readFileSync('./black.webp')}}}})
break
case 'gamemenu':
case 'GameMenu':
momuienu = `┍━━━━┥ *ғᴜɴ ᴍᴇɴᴜ* ┝━━━━
│
┝☐ ${emoji6} ${prefix}sɪᴍɪ
│
┝☐ ${emoji6} ${prefix}ғᴀᴋᴇᴀᴅᴅʀᴇss
│
┝☐ ${emoji6} ${prefix}sʜɪᴛsᴘᴏᴛ
│
┝☐ ${emoji6} ${prefix}ʀᴏʟʟ
│
┝☐ ${emoji6} ${prefix}ɴᴀᴍᴇɴɪɴᴊᴀ
│
┝☐ ${emoji6} ${prefix}ᴀᴍᴏɴɢᴜs
│
┝☐ ${emoji6} ${prefix}ᴛᴀɢᴍᴇ
│
┝☐ ${emoji6} ${prefix}ʀᴘs
│
┝☐ ${emoji6} ${prefix}sɴ
│
┝☐ ${emoji6} ${prefix}ᴄᴀᴛᴛʟᴇ
│
┝☐ ${emoji6} ${prefix}ᴄʜᴀɴᴄᴇ
│
┝☐ ${emoji6} ${prefix}sᴛɪᴄᴋ
│
┝☐ ${emoji6} ${prefix}ɢᴀʏ
│
┝☐ ${emoji6} ${prefix}sʟᴏᴛ
│
┝☐ ${emoji6} ${prefix}sɴᴀɪʟ
│
┝☐ ${emoji6} ${prefix}ʟᴇᴠᴇʟ
│
┝☐ ${emoji6} ${prefix}ʀᴏᴜʟᴇᴛᴛᴇ
│
┝☐ ${emoji6} ${prefix}ᴛᴛᴛ
│
┝☐ ${emoji6} ${prefix}ʙᴜᴛ
│
┝☐ ${emoji6} ${prefix}ᴛᴏᴘ5
│
┕━━━━━━━━━━━━━━━━━━`
hexa.sendMessage(from, momuienu, text, { thumbnail: dnsnew, sendEphemeral: true,quoted: { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc", "mimetype": "image/jpeg","caption": "♟️🧩⚽♠️♣️♥️♦️🎰🎯🎮️", 'jpegThumbnail': fs.readFileSync('./black.webp')}}}})
break
case 'information':
case 'INFORMATION':
mcdomenu = `┍━━━━┥ *ᴜsᴇʀ ɪɴғᴏ* ┝━━━━
│
┝☐ ${emoji1} ɴᴀᴍᴇ: *${pushname}*
│
┝☐ ${emoji1} ᴛʏᴘᴇ: *${prema}*
│
┝☐ ${emoji1} ᴄᴀsʜ: *${checATM}*
│
┝☐ ${emoji1} ʟᴇᴠᴇʟ: *${useLevel}*
│
┝☐ ${emoji1} xᴘ: *${useXp}/${requireXp}*
│
┝☐ ${emoji1} ᴍᴇᴅᴀʟ: *${patt}*
│
┕━━━━━━━━━━━━━━━━━━━
┍━━━━┥ *ᴍᴇɴᴜ ʟɪsᴛ* ┝━━━━
│
┝☐ ${emoji2} ${prefix}ᴍ18
│
┝☐ ${emoji2} ${prefix}sᴍᴇɴᴜ
│
┝☐ ${emoji2} ${prefix}ᴍᴍᴇɴᴜ
│
┕━━━━━━━━━━━━━━━━━━━
┍━━━━┥ *ɪɴғᴏʀᴍᴀᴛɪᴏɴ* ┝━━━━
│
┝☐ ${emoji3} ${prefix}ɪɴғᴏ
│
┝☐ ${emoji3} ${prefix}ᴏᴡɴᴇʀ
│
┝☐ ${emoji3} ${prefix}ᴄʀᴇᴅɪᴛs
│
┝☐ ${emoji3} ${prefix}ᴘɪɴɢ
│
┝☐ ${emoji3} ${prefix}ᴘʀᴏғɪʟᴇ
│
┝☐ ${emoji3} ${prefix}ɪɴғᴏɢᴘ
│
┝☐ ${emoji3} ${prefix}ᴛs
│
┝☐ ${emoji3} ${prefix}ʙᴜɢʀᴇᴘᴏʀᴛ
│
┝☐ ${emoji3} ${prefix}ʀᴇǫᴜᴇsᴛ
│
┝☐ ${emoji3} ${prefix}ᴅᴏɴᴀᴛᴇ
│
┕━━━━━━━━━━━━━━━━━━━`
hexa.sendMessage(from, mcdomenu, text, { thumbnail: dnsnew, sendEphemeral: true,quoted: { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc", "mimetype": "image/jpeg","caption": "✅🗞️🗞️🗞️🗞️👩‍🔧️", 'jpegThumbnail': fs.readFileSync('./black.webp')}}}})
break
case 'relaxbomb':
case 'relax':
relaxb =`[\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nrelax by slayer07\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nrealax by dragu\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nrealx by shaz\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n]`
{ quoted: relaxb }
break
    case 'menux':
    case 'helpx':
    	var menu = `Hai ${pushname}
Prefix : 「 MULTI-PREFIX 」

*</OWNER>*
► _${prefix}off_
► _${prefix}on_
► _${prefix}status_

*</MAKER>*
► _${prefix}sticker_
► _${prefix}swm_ <author|packname>
► _${prefix}take_ <author|packname>
► _${prefix}fdeface_
► _${prefix}emoji_

*</CONVERT>*
► _${prefix}toimg_
► _${prefix}tomp3_
► _${prefix}tomp4_
► _${prefix}slow_
► _${prefix}fast_
► _${prefix}reverse_
► _${prefix}tourl_

*</UP STORY>*
► _${prefix}upswteks_
► _${prefix}upswimage_
► _${prefix}upswvideo_

*</FUN>*
► _${prefix}fitnah_
► _${prefix}fitnahpc_
► _${prefix}kontak_

*</TAG>*
► _${prefix}hidetag_
► _${prefix}kontag_
► _${prefix}sticktag_
► _${prefix}totag_

*</DOWNLOAD>*
► _${prefix}ytsearch_ <query>
► _${prefix}igstalk_ <query>
► _${prefix}play_ <query>
► _${prefix}video_ <query>
► _${prefix}ytmp3_ <link>
► _${prefix}ytmp4_ <link>
► _${prefix}ig_ <link>
► _${prefix}igstory_ <username>
► _${prefix}twitter_ <link>
► _${prefix}tiktok_ <link>
► _${prefix}tiktokaudio_ <link>
► _${prefix}fb_ <link>
► _${prefix}brainly_ <query>
► _${prefix}image_ <query>
► _${prefix}anime_ <random>
► _${prefix}pinterest_ <query>
► _${prefix}komiku_ <query>
► _${prefix}lirik_ <query>
► _${prefix}chara_ <query>
► _${prefix}playstore_ <query>
► _${prefix}otaku_ <query>

*</OTHER>*
► _${prefix}self_
► _${prefix}public_
► _${prefix}setthumb_
► _${prefix}settarget_
► _${prefix}setfakeimg_
► _${prefix}setreply_
► _${prefix}ping_
► _${prefix}inspect_
► _${prefix}join_
► _${prefix}caripesan_ <query>
► _${prefix}get_
► _${prefix}term_ <code>
► _x_ <code>

*</JADI BOT>*
► _${prefix}jadibot_
► _${prefix}stopjadibot_
► _${prefix}listbot_

*</VOTE>*
► _${prefix}voting_
► _${prefix}delvote_
► _vote_
► _devote_

❏ *SELF-BOT* ❏`
        	fakestatus(menu)
           	break
    case 'delvote':
            if(!mek.key.remoteJid) return
            if(isVote) return reply('No Voting session')
            delVote(from)
            reply('Successfully Deleting Voting Session In This Group')
            break
    case 'voting':
            if(!isGroupAdmins && !mek.key.fromMe) return 
            if(!isGroup) return reply(mess.only.group)
            if (isVote) return reply('Voting Session In Progress In This Group')
            if(!q) return reply('*Voting*\n\n'+ prefix+ 'voting @tag target | reason  | 1 (1 = 1 Minute)')
            if (mek.message.extendedTextMessage.contextInfo.mentionedJid.length > 0 || mek.message.extendedTextMessage.contextInfo == null) {
            let id = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
            split = args.join(' ').replace('@', '').split('|')
            if(!Number(split[2])) return reply('enter the number in line 3\nExample: 1-9999\n1 = 1 Minute')
            await mentions('Vote ' +'@'+ id.split('@')[0]+' On Start' +'\n\n' + `vote = ✅\ndevote = ❌\n\nReason: ${split[1]}`,[id],true)
            addVote(from,split[1],split[0],split[2],reply)
            }
            break
    case 'linkwa':
            if(!q) return reply('what group are you looking for?')
            hx.linkwa(q)
            .then(result => {
            let res = '*「 _LINK WA_ 」*\n\n'
            for (let i of result) {
            res += `*Name*: *${i.nama}\n*Link*: ${i.link}\n\n`
            }
            reply(res)
            });
            break

    case 'igstory': 
            if(!q) return reply('Username?')
            hx.igstory(q)
            .then(async result => {
            for(let i of result.medias){
                if(i.url.includes('mp4')){
                    let link = await getBuffer(i.url)
                    hexa.sendMessage(from,link,video,{quoted: mek,caption: `Type : ${i.type}`})
                } else {
                    let link = await getBuffer(i.url)
                    hexa.sendMessage(from,link,image,{quoted: mek,caption: `Type : ${i.type}`})                  
                }
            }
            });
            break
    case 'caripesan':
            if(!q)return reply('what’s the message?')
            let v = await hexa.searchMessages(q,from,10,1)
            let s = v.messages
            let el = s.filter(v => v.message)
            el.shift()
            try {
            if(el[0].message.conversation == undefined) return
            reply(`Found ${el.length} message`)
            await sleep(3000)
            for(let i = 0; i < el.length; i++) {
            await hexa.sendMessage(from,'Here’s the message',text,{quoted:el[i]})
            }
            } catch(e){
            reply('Message not found!')
            }           
            break
    case 'lirik':
            if(!q) return reply('What song is it?')
            let song = await hx.lirik(q)
            sendMediaURL(from,song.thumb,song.lirik)
            break
    case 'otaku':
            if(!q) return reply('anime title?')
            let anime = await hx.otakudesu(q)
            rem = `*Title* : ${anime.judul}
*Japan* : ${anime.jepang}
*Rating* : ${anime.rate}
*Producer* : ${anime.produser}
*Status* : ${anime.status}
*Episode* : ${anime.episode}
*Duration* : ${anime.durasi}
*Release* : ${anime.rilis}
*Studio* : ${anime.studio}
*Genre* : ${anime.genre}\n
*Synopsis* :
${anime.desc}\n\n*Batch Link* : ${anime.batch}\n*SD Download Link* : ${anime.batchSD}\n*HD Download Links* : ${anime.batchHD}`
            ram = await getBuffer(anime.img)
            hexa.sendMessage(from,ram,image,{quoted:mek,caption:rem})
            break
    case 'komiku':
    case 'comics':
            if(!q) return reply(`the title?\n${prefix}my comic or not`)
            let komik = await hx.komiku(q)
            result = `*Title* : ${komik.title}\n
*Indo Title* : ${komik.indo}\n
*Update* : ${komik.update}\n
*Desc* : ${komik.desc}\n
*Early Chapter* : ${komik.chapter_awal}
*Final Chapter* : ${komik.chapter_akhir}`
            sendMediaURL(from, komik.image,result)
            break
    case 'chara':
            if(!q) return reply(`What picture is it?\n${prefix}Chara Nino`)
            let im = await hx.chara(q)
            let acak = im[Math.floor(Math.random() * im.length)]
            let li = await getBuffer(acak)
            await hexa.sendMessage(from,li,image,{quoted: mek})
            break
    case 'on':
            if (!mek.key.fromMe) return 
            offline = false
            fakestatus(' ```YOU’RE ONLINE``` ')
            break       
    case 'status':
            fakestatus(`*STATUS*\n${offline ? '> OFFLINE' : '> ONLINE'}\n${banChats ? '> SELF-MODE' : '> PUBLIC-MODE'}`)
            break
    case 'off':
            if (!mek.key.fromMe) return 
            offline = true
            waktu = Date.now()
            anuu = q ? q : '-'
            alasan = anuu
            fakestatus(' ```YOU ARE OFFLINE``` ')
            break   
    
    case 'sticktag':
            if ((isMedia && !mek.message.videoMessage || isQuotedSticker) && args.length == 0) {
            encmedia = isQuotedSticker ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
            file = await hexa.downloadAndSaveMediaMessage(encmedia, filename = getRandom())
            value = args.join(" ")
            var group = await hexa.groupMetadata(from)
            var member = group['participants']
            var mem = []
            member.map(async adm => {
            mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
            })
            var options = {
                contextInfo: { mentionedJid: mem },
                quoted: mek
            }
            ini_buffer = fs.readFileSync(file)
            hexa.sendMessage(from, ini_buffer, sticker, options)
            fs.unlinkSync(file)
            } else {
            reply(`*Reply sticker that has been sent*`)
            }
            break
    case 'totag':
            if ((isMedia && !mek.message.videoMessage || isQuotedSticker) && args.length == 0) {
            encmedia = isQuotedSticker ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
            file = await hexa.downloadAndSaveMediaMessage(encmedia, filename = getRandom())
            value = args.join(" ")
            var group = await hexa.groupMetadata(from)
            var member = group['participants']
            var mem = []
            member.map(async adm => {
            mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
            })
            var options = {
                contextInfo: { mentionedJid: mem },
                quoted: mek
            }
            ini_buffer = fs.readFileSync(file)
            hexa.sendMessage(from, ini_buffer, sticker, options)
            fs.unlinkSync(file)
            } else if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
            encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
            file = await hexa.downloadAndSaveMediaMessage(encmedia, filename = getRandom())
            value = args.join(" ")
            var group = await hexa.groupMetadata(from)
            var member = group['participants']
            var mem = []
            member.map(async adm => {
            mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
            })
            var options = {
                contextInfo: { mentionedJid: mem },
                quoted: mek
            }
            ini_buffer = fs.readFileSync(file)
            hexa.sendMessage(from, ini_buffer, image, options)
            fs.unlinkSync(file)
        } else if ((isMedia && !mek.message.videoMessage || isQuotedAudio) && args.length == 0) {
            encmedia = isQuotedAudio ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
            file = await hexa.downloadAndSaveMediaMessage(encmedia, filename = getRandom())
            value = args.join(" ")
            var group = await hexa.groupMetadata(from)
            var member = group['participants']
            var mem = []
            member.map(async adm => {
            mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
            })
            var options = {
            	mimetype : 'audio/mp4',
            	ptt : true,
                contextInfo: { mentionedJid: mem },
                quoted: mek
            }
            ini_buffer = fs.readFileSync(file)
            hexa.sendMessage(from, ini_buffer, audio, options)
            fs.unlinkSync(file)
        }  else if ((isMedia && !mek.message.videoMessage || isQuotedVideo) && args.length == 0) {
            encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
            file = await hexa.downloadAndSaveMediaMessage(encmedia, filename = getRandom())
            value = args.join(" ")
            var group = await hexa.groupMetadata(from)
            var member = group['participants']
            var mem = []
            member.map(async adm => {
            mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
            })
            var options = {
            	mimetype : 'video/mp4',
                contextInfo: { mentionedJid: mem },
                quoted: mek
            }
            ini_buffer = fs.readFileSync(file)
            hexa.sendMessage(from, ini_buffer, video, options)
            fs.unlinkSync(file)
        } else{
          reply(`picture reply/sticker/audio/video with caption ${prefix}totag`)
        }
        break
    case 'fitnah':
            if (args.length < 1) return reply(`Usage :\n${prefix}fitnah [@tag|message|replybot]]\n\nEx : \n${prefix}fitnah @tagmember|hai|Hi also`)
            var gh = args.join('')
            mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
            var replace = gh.split("|")[0];
            var target = gh.split("|")[1];
            var bot = gh.split("|")[2];
            hexa.sendMessage(from, `${bot}`, text, {quoted: { key: { fromMe: false, participant: `${mentioned}`, ...(from ? { remoteJid: from } : {}) }, message: { conversation: `${target}` }}})
            break
    case 'settarget':
            if(!q) return reply(`${prefix}settarget 918xxxxx`)
            targetpc = args[0]
            fakegroup(`Success Changing the target of slanderpc : ${targetpc}`)
            break
    case 'fitnahpc':
            if(!q) return reply(`${prefix}fitnahpc teks target|teks lu`)
            jids = `${targetpc}@s.whatsapp.net` // nomer target
            var split = args.join(' ').replace(/@|\d/gi, '').split('|')
            var taged = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
            var options = {contextInfo: {quotedMessage: {extendedTextMessage: {text: split[0]}}}}
            const responye = await hexa.sendMessage(jids, `${split[1]}`, MessageType.text, options)
            await hexa.deleteMessage(jids, { id: responye.messageID, remoteJid: jids, fromMe: true })
            break
    case 'fast':
            if (!isQuotedVideo) return fakegroup('Reply videonya!')
            fakegroup(mess.wait)
            encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
            media = await hexa.downloadAndSaveMediaMessage(encmedia)
            ran = getRandom('.mp4')
            exec(`ffmpeg -i ${media} -filter_complex "[0:v]setpts=0.5*PTS[v];[0:a]atempo=2[a]" -map "[v]" -map "[a]" ${ran}`, (err) => {
            fs.unlinkSync(media)
            if (err) return fakegroup(`Err: ${err}`)
            buffer453 = fs.readFileSync(ran)
            hexa.sendMessage(from, buffer453, video, { mimetype: 'video/mp4', quoted: mek })
            fs.unlinkSync(ran)
            })
            break
    case 'slow':
            if (!isQuotedVideo) return fakegroup('Reply videonya!')
            fakegroup(mess.wait)
            encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
            media = await hexa.downloadAndSaveMediaMessage(encmedia)
            ran = getRandom('.mp4')
            exec(`ffmpeg -i ${media} -filter_complex "[0:v]setpts=2*PTS[v];[0:a]atempo=0.5[a]" -map "[v]" -map "[a]" ${ran}`, (err) => {
            fs.unlinkSync(media)
            if (err) return fakegroup(`Err: ${err}`)
            buffer453 = fs.readFileSync(ran)
            hexa.sendMessage(from, buffer453, video, { mimetype: 'video/mp4', quoted: mek })
            fs.unlinkSync(ran)
            })
            break
    case 'reverse':
            if (!isQuotedVideo) return fakegroup('Reply videonya!')
            encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
            media = await hexa.downloadAndSaveMediaMessage(encmedia)
            ran = getRandom('.mp4')
            exec(`ffmpeg -i ${media} -vf reverse -af areverse ${ran}`, (err) => {
            fs.unlinkSync(media)
            if (err) return fakegroup(`Err: ${err}`)
            buffer453 = fs.readFileSync(ran)
            hexa.sendMessage(from, buffer453, video, { mimetype: 'video/mp4', quoted: mek })
            fs.unlinkSync(ran)
            })
            break
    case 'anime':
            reply(mess.wait)
            fetch('https://raw.githubusercontent.com/pajaar/grabbed-results/master/pajaar-2020-gambar-anime.txt')
            .then(res => res.text())
            .then(body => {
            let tod = body.split("\n");
            let pjr = tod[Math.floor(Math.random() * tod.length)];
            imageToBase64(pjr)
            .then((response) => {
            media =  Buffer.from(response, 'base64');
            hexa.sendMessage(from,media,image,{quoted:mek,caption:'NIH'})
            }
            )
            .catch((error) => {
            console.log(error); 
            }
            )
            });
            break
    case 'kontak':
            pe = args.join(' ') 
            entah = pe.split('|')[0]
            nah = pe.split('|')[1]
            if (isNaN(entah)) return reply('Invalid phone number');
            vcard = 'BEGIN:VCARD\n'
            + 'VERSION:3.0\n'
            + `FN:${nah}\n`
            + `TEL;type=CELL;type=VOICE;waid=${entah}:${phoneNum('+' + entah).getNumber('internasional')}\n`
            + 'END:VCARD'.trim()
            hexa.sendMessage(from, {displayName: `${nah}`, vcard: vcard}, contact)
            break    
    case 'take':
    case 'colong':
    		if (!isQuotedSticker) return reply('Just a sticker')
            encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
		    media = await hexa.downloadAndSaveMediaMessage(encmedia)
            anu = args.join(' ').split('|')
            satu = anu[0] !== '' ? anu[0] : `White Walker`
            dua = typeof anu[1] !== 'undefined' ? anu[1] : `A.bin`
            require('./lib/fetcher.js').createExif(satu, dua)
			require('./lib/fetcher.js').modStick(media, hexa, mek, from)
			break
	case 'stikerwm':
	case 'stickerwm':
    case 'swm':
            pe = args.join('')
            var a = pe.split("|")[0];
            var b = pe.split("|")[1];
            if (isMedia && !mek.message.videoMessage || isQuotedImage ) {
            const encmedia = isQuotedImage   ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
             media = await hexa.downloadAndSaveMediaMessage(encmedia)
            await createExif(a,b)
            out = getRandom('.webp')
            ffmpeg(media)
            .on('error', (e) => {
            console.log(e)
            hexa.sendMessage(from, 'Terjadi kesalahan', 'conversation', { quoted: mek })
            fs.unlinkSync(media)
            })
            .on('end', () => {
            _out = getRandom('.webp')
            spawn('webpmux', ['-set','exif','./stik/data.exif', out, '-o', _out])
            .on('exit', () => {
            hexa.sendMessage(from, fs.readFileSync(_out),'stickerMessage', { quoted: mek })
            fs.unlinkSync(out)
            fs.unlinkSync(_out)
            fs.unlinkSync(media)
            })
            })
            .addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
            .toFormat('webp')
            .save(out) 
            } else if ((isMedia && mek.message.videoMessage.seconds < 11 || isQuotedVideo && mek.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.seconds < 11) && args.length == 0) {
            const encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
            const media = await hexa.downloadAndSaveMediaMessage(encmedia)
            pe = args.join('')
            var a = pe.split("|")[0];
            var b = pe.split("|")[1];
            await createExif(a,b)
            out = getRandom('.webp')
            ffmpeg(media)
            .on('error', (e) => {
            console.log(e)
            hexa.sendMessage(from, 'Terjadi kesalahan', 'conversation', { quoted: mek })
            fs.unlinkSync(media)
            })
            .on('end', () => {
            _out = getRandom('.webp')
            spawn('webpmux', ['-set','exif','./stik/data.exif', out, '-o', _out])
            .on('exit', () => {
            hexa.sendMessage(from, fs.readFileSync(_out),'stickerMessage', { quoted: mek })
            fs.unlinkSync(out)
            fs.unlinkSync(_out)
            fs.unlinkSync(media)
            })
            })
            .addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
            .toFormat('webp')
            .save(out)       
            } else {
            reply(`Kirim gambar dengan caption ${prefix}swm teks|teks atau tag gambar yang sudah dikirim`)
            }
            break
    case 'upswteks':
            if (!q) return fakestatus('Isi teksnya!')
            hexa.sendMessage('status@broadcast', `${q}`, extendedText)
            fakegroup(`Sukses Up story wea teks ${q}`)
            break
    case 'upswimage':
            if (isQuotedImage) {
            const swsw = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
            cihcih = await hexa.downloadMediaMessage(swsw)
            hexa.sendMessage('status@broadcast', cihcih, image, { caption: `${q}` })
            bur = `Sukses Upload Story Image dengan Caption: ${q}`
            hexa.sendMessage(from, bur, text, { quoted: mek })
            } else {
            fakestatus('Reply gambarnya!')
            }
            break
    case 'upswvideo':
            if (isQuotedVideo) {
            const swsw = isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
            cihcih = await hexa.downloadMediaMessage(swsw)
            hexa.sendMessage('status@broadcast', cihcih, video, { caption: `${q}` }) 
            bur = `Sukses Upload Story Video dengan Caption: ${q}`
            hexa.sendMessage(from, bur, text, { quoted: mek })
            } else {
            fakestatus('reply videonya!')
            }
            break
    case 'public':
          	if (!mek.key.fromMe) return fakestatus('SELF-BOT')
          	if (banChats === false) return
          	// var taged = ben.message.extendedTextMessage.contextInfo.mentionedJid[0]
          	banChats = false
          	fakestatus(`「 *PUBLIC-MODE* 」`)
          	break
	case 'self':
          	if (!mek.key.fromMe) return fakestatus('SELF-BOT')
          	if (banChats === true) return
          	uptime = process.uptime()
         	 // var taged = ben.message.extendedTextMessage.contextInfo.mentionedJid[0]
         	banChats = true
          	fakestatus(`「 *SELF-MODE* 」`)
          	break
 	case 'hidetag':
			if (!mek.key.fromMe) return fakestatus('SELF-BOT')
			if (!isGroup) return reply(mess.only.group)
			var value = args.join(' ')
			var group = await hexa.groupMetadata(from)
			var member = group['participants']
			var mem = []
			member.map(async adm => {
			mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
			})
			var optionshidetag = {
			text: value,
			contextInfo: { mentionedJid: mem },
			quoted: mek
			}
			hexa.sendMessage(from, optionshidetag, text)
			break
	  
        case 'video':
            if (args.length === 0) return reply(`Kirim perintah *${prefix}video* _Judul lagu yang akan dicari_`)
            var srch = args.join('')
            aramas = await yts(srch);
            aramat = aramas.all 
            var mulaikah = aramat[0].url                            
                  try {
                    ytv(mulaikah)
                    .then((res) => {
                        const { dl_link, thumb, title, filesizeF, filesize } = res
                        axios.get(`https://tinyurl.com/api-create.php?url=${dl_link}`)
                        .then(async (a) => {
                        if (Number(filesize) >= 100000) return sendMediaURL(from, thumb, `*PLAY VIDEO*\n\n*Title* : ${title}\n*Ext* : MP3\n*Filesize* : ${filesizeF}\n*Link* : ${a.data}\n\n_Untuk durasi lebih dari batas disajikan dalam mektuk link_`)
                        const captions = `*PLAY VIDEO*\n\n*Title* : ${title}\n*Ext* : MP4\n*Size* : ${filesizeF}\n*Link* : ${a.data}\n\n_Silahkan tunggu file media sedang dikirim mungkin butuh beberapa menit_`
                        sendMediaURL(from, thumb, captions)
                        await sendMediaURL(from, dl_link).catch(() => reply('error'))
                        })                
                        })
                        } catch (err) {
                        reply(mess.error.api)
                        }
                   break
	case 'ytsearch':
			if (args.length < 1) return reply('Tolong masukan query!')
			var srch = args.join('');
			try {
        	var aramas = await yts(srch);
   			} catch {
        	return await hexa.sendMessage(from, 'Error!', MessageType.text, dload)
    		}
    		aramat = aramas.all 
    		var tbuff = await getBuffer(aramat[0].image)
    		var ytresult = '';
    		ytresult += '「 *YOUTUBE SEARCH* 」'
    		ytresult += '\n________________________\n\n'
   			aramas.all.map((video) => {
        	ytresult += '❏ Title: ' + video.title + '\n'
            ytresult += '❏ Link: ' + video.url + '\n'
            ytresult += '❏ Durasi: ' + video.timestamp + '\n'
            ytresult += '❏ Upload: ' + video.ago + '\n________________________\n\n'
    		});
    		ytresult += '◩ *SELF-BOT*'
    		await fakethumb(tbuff,ytresult)
			break
	case 'setreply':
	case 'setfake':
			if (!q) return fakegroup(mess.wrongFormat)
			fake = q
			fakegroup(`Succes Mengganti Conversation Fake : ${q}`)
			break
	case 'setfakeimg':
        	if ((isMedia && !mek.message.videoMessage || isQuotedImage || isQuotedSticker) && args.length == 0) {
          	boij = isQuotedImage || isQuotedSticker ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
			delb = await hexa.downloadMediaMessage(boij)
			fs.writeFileSync(`./stik/fake.jpeg`, delb)
			fakestatus('Sukses')
        	} else {
            reply(`Kirim gambar dengan caption ${prefix}sethumb`)
          	}
			break	
	case 'setthumb':
	        if ((isMedia && !mek.message.videoMessage || isQuotedImage || isQuotedSticker) && args.length == 0) {
          	boij = isQuotedImage || isQuotedSticker ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
			delb = await hexa.downloadMediaMessage(boij)
			fs.writeFileSync(`./stik/thumb.jpeg`, delb)
			fakestatus('Sukses')
        	} else {
            reply(`Kirim gambar dengan caption ${prefix}sethumb`)
          	}
			break	
	case 'ytmp4':
			if (args.length === 0) return reply(`Kirim perintah *${prefix}ytmp4 [linkYt]*`)
			let isLinks2 = args[0].match(/(?:https?:\/{2})?(?:w{3}\.)?youtu(?:be)?\.(?:com|be)(?:\/watch\?v=|\/)([^\s&]+)/)
			if (!isLinks2) return reply(mess.error.Iv)
				try {
				reply(mess.wait)
				ytv(args[0])
				.then((res) => {
				const { dl_link, thumb, title, filesizeF, filesize } = res
				axios.get(`https://tinyurl.com/api-create.php?url=${dl_link}`)
				.then((a) => {
				if (Number(filesize) >= 40000) return sendMediaURL(from, thumb, `*YTMP 4!*\n\n*Title* : ${title}\n*Ext* : MP3\n*Filesize* : ${filesizeF}\n*Link* : ${a.data}\n\n_Untuk durasi lebih dari batas disajikan dalam mektuk link_`)
				const captionsYtmp4 = `*Data Berhasil Didapatkan!*\n\n*Title* : ${title}\n*Ext* : MP4\n*Size* : ${filesizeF}\n\n_Silahkan tunggu file media sedang dikirim mungkin butuh beberapa menit_`
				sendMediaURL(from, thumb, captionsYtmp4)
				sendMediaURL(from, dl_link).catch(() => reply(mess.error.api))
				})		
				})
				} catch (err) {
			    reply(mess.error.api)
				}
				break
    case 'image':
            if (args.length < 1) return reply('Masukan teks!')
            const gimg = args.join('');
            reply(mess.wait)
            gis(gimg, async (error, result) => {
            n = result
            images = n[Math.floor(Math.random() * n.length)].url
            hexa.sendMessage(from,{url:images},image,{quoted:mek})
            });
            break
 	case 'tiktok':
 		if (!isUrl(args[0]) && !args[0].includes('tiktok.com')) return reply(mess.Iv)
 		if (!q) return fakegroup('Linknya?')
 		reply(mess.wait)
		hx.ttdownloader(`${args[0]}`)
    		.then(result => {
    		const { wm, nowm, audio } = result
    		axios.get(`https://tinyurl.com/api-create.php?url=${nowm}`)
    		.then(async (a) => {
    		me = `*Link* : ${a.data}`
		hexa.sendMessage(from,{url:`${nowm}`},video,{mimetype:'video/mp4',quoted:mek,caption:me})
		})
		})
     		.catch(e => console.log(e))
     		break
    case 'tiktokaudio':
 		if (!isUrl(args[0]) && !args[0].includes('tiktok.com')) return reply(mess.Iv)
 		if (!q) return fakegroup('Linknya?')
 		reply(mess.wait)
 		hx.ttdownloader(`${args[0]}`)
    		.then(result => {
    		const { audio} = result
            sendMediaURL(from,audio,'')
    		})
     		.catch(e => console.log(e))
     		break
    case 'brainly':
			if (args.length < 1) return reply('Pertanyaan apa')
          	brien = args.join(' ')
			brainly(`${brien}`).then(res => {
			teks = '❉───────────────────────❉\n'
			for (let Y of res.data) {
			teks += `\n*「 _BRAINLY_ 」*\n\n*➸ Pertanyaan:* ${Y.pertanyaan}\n\n*➸ Jawaban:* ${Y.jawaban[0].text}\n❉──────────────────❉\n`
			}
			hexa.sendMessage(from, teks, text,{quoted:mek,detectLinks: false})                        
            })              
			break
    case 'ig':
        if (!isUrl(args[0]) && !args[0].includes('instagram.com')) return reply(mess.Iv)
        if (!q) return fakegroup('Linknya?')
        reply(mess.wait)
	    hx.igdl(args[0])
	    .then(async(result) => {
            for(let i of result.medias){
                if(i.url.includes('mp4')){
                    let link = await getBuffer(i.url)
                    hexa.sendMessage(from,link,video,{quoted: mek,caption: `Type : ${i.type}`})
                } else {
                    let link = await getBuffer(i.url)
                    hexa.sendMessage(from,link,image,{quoted: mek,caption: `Type : ${i.type}`})                  
                }
            }
            });
	    break
    case 'igstalk':
            if (!q) return fakegroup('Usernamenya?')
            ig.fetchUser(`${args.join(' ')}`).then(Y => {
            console.log(`${args.join(' ')}`)
            ten = `${Y.profile_pic_url_hd}`
            teks = `*ID* : ${Y.profile_id}\n*Username* : ${args.join('')}\n*Full Name* : ${Y.full_name}\n*Bio* : ${Y.biography}\n*Followers* : ${Y.followers}\n*Following* : ${Y.following}\n*Private* : ${Y.is_private}\n*Verified* : ${Y.is_verified}\n\n*Link* : https://instagram.com/${args.join('')}`
            sendMediaURL(from,ten,teks) 
            })      
            break    
    case 'fb':
            if (!q) return reply('Linknya?')
            if (!isUrl(args[0]) && !args[0].includes('facebook.com')) return reply(mess.Iv)
            reply(mess.wait)
            te = args.join(' ')
            hx.fbdown(`${te}`)
            .then(G => {
            ten = `${G.HD}`
            sendMediaURL(from,ten,`*Link video_normal* : ${G.Normal_video}`)
            })
            break    
	case 'term':
			if (!q) return fakegroup(mess.wrongFormat)
			exec(q, (err, stdout) => {
			if (err) return fakegroup(`SELF-BOT:~ ${err}`)
			if (stdout) {
			fakegroup(stdout)
			}
			})
		    break 
    case 'join':
            try {
            if (!isUrl(args[0]) && !args[0].includes('whatsapp.com')) return reply(mess.Iv)
            hen = args[0]
            if (!q) return fakestatus('Masukan link group')
            var codeInvite = hen.split('https://chat.whatsapp.com/')[1]
            if (!codeInvite) return fakegroup ('pastikan link sudah benar!')
            var response = await hexa.acceptInvite(codeInvite)
            fakestatus('SUKSES')
            } catch {
            fakegroup('LINK ERROR!')
            }
            break
    case'twitter':
            if (!isUrl(args[0]) && !args[0].includes('twitter.com')) return reply(mess.Iv)
            if (!q) return fakegroup('Linknya?')
            ten = args[0]
            var res = await hx.twitter(`${ten}`)
            ren = `${g.HD}`
            sendMediaURL(from,ren,'DONE')
            break
    case 'runtime':
    case 'test':
            run = process.uptime() 
            teks = `${kyun(run)}`
            fakegroup(teks)
            break  
	case 'speedx':
	case 'pingx':
			exec(`neofetch --stdout`, (error, stdout, stderr) => {
			const child = stdout.toString('utf-8')
			const teks = child.replace(/Memory:/, "Ram:")
			const pingnya = `*${teks}Speed: ${latensi.toFixed(4)} Second*`
			fakegroup(pingnya)
			})
			break  
    case 'totag':
            if ((isMedia && !mek.message.videoMessage || isQuotedSticker) && args.length == 0) {
            encmedia = isQuotedSticker ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
            file = await hexa.downloadAndSaveMediaMessage(encmedia, filename = getRandom())
            value = args.join(" ")
            var group = await hexa.groupMetadata(from)
            var member = group['participants']
            var mem = []
            member.map(async adm => {
            mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
            })
            var options = {
                contextInfo: { mentionedJid: mem },
                quoted: mek
            }
            ini_buffer = fs.readFileSync(file)
            hexa.sendMessage(from, ini_buffer, sticker, options)
            fs.unlinkSync(file)
            } else if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
            encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
            file = await hexa.downloadAndSaveMediaMessage(encmedia, filename = getRandom())
            value = args.join(" ")
            var group = await hexa.groupMetadata(from)
            var member = group['participants']
            var mem = []
            member.map(async adm => {
            mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
            })
            var options = {
                contextInfo: { mentionedJid: mem },
                quoted: mek
            }
            ini_buffer = fs.readFileSync(file)
            hexa.sendMessage(from, ini_buffer, image, options)
            fs.unlinkSync(file)
        } else if ((isMedia && !mek.message.videoMessage || isQuotedAudio) && args.length == 0) {
            encmedia = isQuotedAudio ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
            file = await hexa.downloadAndSaveMediaMessage(encmedia, filename = getRandom())
            value = args.join(" ")
            var group = await hexa.groupMetadata(from)
            var member = group['participants']
            var mem = []
            member.map(async adm => {
            mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
            })
            var options = {
                mimetype : 'audio/mp4',
                ptt : true,
                contextInfo: { mentionedJid: mem },
                quoted: mek
            }
            ini_buffer = fs.readFileSync(file)
            hexa.sendMessage(from, ini_buffer, audio, options)
            fs.unlinkSync(file)
        }  else if ((isMedia && !mek.message.videoMessage || isQuotedVideo) && args.length == 0) {
            encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
            file = await hexa.downloadAndSaveMediaMessage(encmedia, filename = getRandom())
            value = args.join(" ")
            var group = await hexa.groupMetadata(from)
            var member = group['participants']
            var mem = []
            member.map(async adm => {
            mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
            })
            var options = {
                mimetype : 'video/mp4',
                contextInfo: { mentionedJid: mem },
                quoted: mek
            }
            ini_buffer = fs.readFileSync(file)
            hexa.sendMessage(from, ini_buffer, video, options)
            fs.unlinkSync(file)
        } else{
          reply(`reply gambar/sticker/audio/video dengan caption ${prefix}totag`)
        }
        break	
    case 'inspect':
            try {
            if (!isUrl(args[0]) && !args[0].includes('whatsapp.com')) return reply(mess.Iv)
            if (!q) return reply('masukan link wa')
            cos = args[0]
            var net = cos.split('https://chat.whatsapp.com/')[1]
            if (!net) return reply('pastikan itu link https://whatsapp.com/')
            jids = []
            let { id, owner, subject, subjectOwner, desc, descId, participants, size, descOwner, descTime, creation} = await hexa.query({ 
            json: ["query", "invite",net],
            expect200:true })
            let par = `*Id* : ${id}
${owner ? `*Owner* : @${owner.split('@')[0]}` : '*Owner* : -'}
*Nama Gc* : ${subject}
*Gc dibuat Tanggal* : ${formatDate(creation * 1000)}
*Jumlah Member* : ${size}
${desc ? `*Desc* : ${desc}` : '*Desc* : tidak ada'}
*Id desc* : ${descId}
${descOwner ? `*Desc diubah oleh* : @${descOwner.split('@')[0]}` : '*Desc diubah oleh* : -'}\n*Tanggal* : ${descTime ? `${formatDate(descTime * 1000)}` : '-'}\n\n*Kontak yang tersimpan*\n`
           for ( let y of participants) {
             par += `> @${y.id.split('@')[0]}\n*Admin* : ${y.isAdmin ? 'Ya' : 'Tidak'}\n`
             jids.push(`${y.id.replace(/@c.us/g,'@s.whatsapp.net')}`)
             }
             jids.push(`${owner ? `${owner.replace(/@c.us/g,'@s.whatsapp.net')}` : '-'}`)
             jids.push(`${descOwner ? `${descOwner.replace(/@c.us/g,'@s.whatsapp.net')}` : '-'}`)
             hexa.sendMessage(from,par,text,{quoted:mek,contextInfo:{mentionedJid:jids}})
             } catch {
             reply('Link error')
             }
             break
default:
if (budy.startsWith('x')){
try {
return hexa.sendMessage(from, JSON.stringify(eval(budy.slice(2)),null,'\t'),text, {quoted: mek})
} catch(err) {
e = String(err)
reply(e)
}
}  

	}
if (isGroup && budy != undefined) {
	} else {
	console.log(color('[TEXT]', 'red'), 'SELF-MODE', color(sender.split('@')[0]))
	}		
	} catch (e) {
    e = String(e)
    if (!e.includes("this.isZero") && !e.includes("jid")) {
	console.log('Message : %s', color(e, 'green'))
        }
	// console.log(e)
	}
}


	
    
